# RSD DH08 · Hồ sơ Tour

**TOPAS · Module Điều hành · Phiên bản 2.2 · 12/11/2026**
Phần mềm cho doanh nghiệp lữ hành chuyên Tour Inbound và Tour Customized.

- **Nguồn nghiệp vụ.** `luồng/danh-sach-man-hinh-level1.md` (DH08, DH08.1–DH08.8 và vòng đời trạng thái), luồng `SYS05`–`SYS09` và các quyết định đã chốt với người dùng ngày 10/11/2026; RSD DH07 v1.1 và RSD DH01 v1.0.
- **Thay đổi ở v2.2.** Sắp xếp lại tài liệu, không đổi nghiệp vụ. Wireframe đặt ngay dưới bước luồng tương ứng. Đặc tả thao tác và phản hồi giao diện (mục 8 cũ) gộp vào từng bước. Bỏ mục Wireframe riêng (mục 6 cũ) và bảng Sự kiện tự động (đã có trong luồng và quy tắc R). Nút theo trạng thái gộp vào header; quy tắc giao diện dùng chung gộp với xử lý dùng chung. Mã L, E, R, W, AC giữ nguyên.
- **Thay đổi ở v2.1.** Đồng bộ với RSD DH01 v1.0: checklist sinh từ một mẫu theo loại Tour, có phiên bản (mục 5.1, R03); thêm hạng mục thì sinh việc theo dịch vụ của mẫu hồ sơ đã dùng, phiên bản hiện hành (L2.5, R19); bảng trượt công việc hiện mẫu, phiên bản và hướng dẫn thực hiện (W12); giao người phụ trách lần đầu điền người thực hiện cho việc có Giao người phụ trách (L1.2). Dữ liệu minh họa ở W10–W12 khớp mẫu Inbound tiêu chuẩn v4 của DH01.
- **Cách đọc.** Mục 3 mô tả luồng theo tab. Mỗi bước ghi mã W, chỗ bấm, thao tác của người dùng và phản hồi của hệ thống; hình wireframe nằm ngay dưới bước. Mục 4 ghi quy tắc (mã R) mà các bước dẫn tới.
- **Wireframe.** Ảnh chụp từ khung HTML desktop, 1280 × 800 px. Chụp lại bằng `node build.js` trong `wireframes-src`. Tên, email, mã và số tiền trên hình chỉ dùng để minh họa.

## Mục lục

1. Phạm vi và quyền
2. Khung hồ sơ, trạng thái và quy ước giao diện
3. Luồng thao tác kèm wireframe
4. Quy tắc triển khai chi tiết
5. Dữ liệu
6. Tiêu chí nghiệm thu

---

## 1. Phạm vi và quyền

### 1.1. Mục tiêu

DH08 là hồ sơ làm việc của một Tour, gắn với một Tour Code. Hồ sơ đi từ lúc DH07 tạo từ Booking đến khi Tour đã vận hành, đã quyết toán và đã đóng. Mục tiêu thiết kế:

- **Biết ngay việc cần làm tiếp.** Tổng quan tổng hợp mức sẵn sàng của checklist, đặt dịch vụ, giấy tờ khách, phân phòng và HDV. Mỗi dòng có nút đưa thẳng tới đúng việc.
- **Ít nhập lại.** Hệ thống điền sẵn email đặt dịch vụ, yêu cầu riêng của khách, giá gợi ý cho quyết toán và chuyến bay chung của đoàn. Người dùng chỉ kiểm tra rồi xác nhận.
- **Thao tác hàng loạt khi việc lặp lại.** Áp dụng cho đặt nhiều dịch vụ (gộp theo NCC), hủy theo Booking đã hủy, gán chuyến bay cho nhiều khách, phân công nhiều công việc, gửi Pax list cho nhiều NCC và ghi công nợ nhiều khoản.
- **Nghiệp vụ Inbound.** Quản lý hộ chiếu, visa, chuyến bay, yêu cầu riêng (ăn uống, phòng) và ngôn ngữ phục vụ của đoàn.

### 1.2. Lối vào và lối ra

| Từ / đến | Hành vi |
|---|---|
| DH07 → DH08 | Chọn dòng hồ sơ hoặc tạo hồ sơ từ Booking để mở DH08 ở tab Tổng quan. |
| KD08.1 → DH08 | Mở hồ sơ của Booking. Liên kết Khách đoàn mở thẳng DH08.4. |
| KD08 → DH08 | Kinh doanh sửa lịch trình và bấm Gửi Điều hành; hồ sơ hiện thông báo Chương trình có thay đổi (W08). |
| KD04.2 → DH08 | Mở Tour đã đóng ở chế độ chỉ đọc. |
| KT01.3 → DH08.8 | Từ bộ lọc Tour đã kết thúc chưa quyết toán, mở tab Quyết toán. |
| QT07, QT09, QT11, QT12 → DH08 | Mở đúng tab: DH08.8, DH08.3, DH08.6 hoặc DH08.7. |
| DH08.7 → KT01.3 | Kế toán ghi công nợ; Tour Code và khoản phát sinh điền sẵn. |
| DH08.3 → KT01.2 | Dịch vụ đã xác nhận và phí hủy tự vào bộ lọc Chờ ghi phải trả. |
| DH08.8 → KD04.2 | Khi đóng Tour, khách được đưa vào chăm sóc sau Tour. |
| Header → KD08 | Liên kết Booking mở KD08 nếu người dùng có quyền xem Booking. |

### 1.3. Ranh giới

- DH08 **không sở hữu** các dữ liệu sau và chỉ đọc hoặc mở màn nguồn: Booking và giá bán đã chốt (KD08, KD06.3), sổ công nợ và giao dịch thu chi (KT01), hồ sơ NCC (DH03, gồm hợp đồng, chính sách đổi hủy, chính sách trẻ em, điều khoản thanh toán; dịch vụ và bảng giá ở DH05 thuộc hồ sơ NCC), nhân sự (DH06), mẫu checklist (DH01), mẫu email và mẫu tài liệu (QT04.2).
- Việc tạo hồ sơ, sinh Tour Code, bóc tách dịch vụ và tạo checklist thuộc DH07. DH08 nhận kết quả đó làm dữ liệu đầu vào.
- Booking có hai trạng thái theo nguồn: Hiệu lực và Đã hủy. Booking ở trạng thái Hiệu lực không cần thanh toán đủ. Thay đổi chương trình sau khi tạo hồ sơ do Kinh doanh sửa lịch trình ở màn Kinh doanh (KD08) rồi bấm Gửi Điều hành. Kinh doanh không thao tác trong DH08. DH08 nhận, hiển thị và áp dụng thay đổi khi Điều hành bấm Áp dụng (L1.5, R19). Giá bán vẫn do KD08 quản lý. Thay đổi số khách và thông tin khách được ghi tại DH08.4.
- Email gửi NCC đi từ hộp thư chung đã cấu hình, có CC người thao tác. DH08 không đọc hộp thư đến; người dùng tự ghi kết quả từ NCC.
- Nhật ký nghiệp vụ ở DH08.6 tách biệt với nhật ký thao tác người dùng ở QT03.

### 1.4. Quyền theo khu vực

| Khu vực | Điều hành | Kinh doanh | Kế toán |
|---|---|---|---|
| Khung, DH08.1 Tổng quan | Sửa thông tin điều hành; bắt đầu, kết thúc Tour; xem và áp dụng thay đổi chương trình | Xem (sửa lịch trình và gửi Điều hành ở màn Kinh doanh) | Xem |
| DH08.2 Dịch vụ và checklist | Thêm, sửa, bỏ dịch vụ; phân công; cập nhật tiến độ | Xem | Xem |
| DH08.3 Đặt dịch vụ | Gửi đặt, đặt lại, hủy; ghi kết quả; gửi điều chỉnh; báo Kinh doanh | Xem; nhận yêu cầu đổi lịch trình (xử lý bằng cách sửa lịch trình ở màn Kinh doanh) | Xem |
| DH08.4 Khách đoàn: danh sách khách, yêu cầu riêng | Xem | Thêm, sửa, nhập Excel, gán chuyến bay | Xem |
| DH08.4 Phân phòng, Pax list, Rooming list | Xếp phòng, tải, gửi NCC | Xem | Xem |
| DH08.5 Nhân sự | Phân công, sửa, bỏ | Xem | Xem |
| DH08.6 Nhật ký và sự cố | Thêm, cập nhật kết quả | Xem | Xem |
| DH08.7 Chi phí phát sinh | Thêm, sửa khoản chưa ghi công nợ | Xem | Ghi công nợ (mở KT01.3) |
| DH08.8 Quyết toán | Nhập chi phí thực tế; đóng Tour; mở lại (chỉ người phụ trách hồ sơ) | Xem | Đối chiếu, điều chỉnh, lưu quyết toán |

- **Phạm vi bản ghi.** Điều hành và Kế toán xem mọi hồ sơ. Kinh doanh xem hồ sơ của Booking mình phụ trách.
- **Ẩn và khóa.** Người chỉ có quyền xem không thấy nút ghi, nhưng vẫn mở được dòng để xem chi tiết. Máy chủ kiểm tra quyền và trạng thái hồ sơ khi ghi.
- **Chỉ đọc sau khi đóng.** Mọi tab chuyển chỉ đọc. Người phụ trách hồ sơ thấy thêm nút Mở lại Tour. KT01 tiếp tục ghi thu chi theo Tour Code.
- **Dữ liệu cá nhân.** Danh sách che số hộ chiếu (giữ 4 ký tự đầu và 2 ký tự cuối). Số đầy đủ chỉ hiển thị trong form khách với người có quyền sửa khách, và trong tệp gửi NCC có cột hộ chiếu.

---

## 2. Khung hồ sơ, trạng thái và quy ước giao diện

### 2.1. Header và tab (W01)

| Vùng | Nội dung | Nguồn |
|---|---|---|
| Dòng 1 | Tour Code, nhãn trạng thái hồ sơ, chỉ báo phụ (Booking đã hủy, Đã quyết toán, Đã mở lại), nút theo trạng thái ở bên phải | Hồ sơ Tour |
| Dòng 2 | Booking (liên kết), khách và số khách, thời gian và số ngày đêm, ngôn ngữ phục vụ, Điều hành phụ trách, phải thu còn, phải trả còn | KD08, DH08.1, KT01 (số dư theo Tour Code) |
| Tab | Tổng quan · Dịch vụ & checklist · Đặt dịch vụ · Khách đoàn · Nhân sự · Nhật ký & sự cố · Chi phí phát sinh · Quyết toán | — |

**Nút theo trạng thái.** Mới tạo: Thông tin điều hành, Bắt đầu Tour (khi Booking đã hủy, Bắt đầu Tour khóa và Kết thúc hồ sơ hiện ra, R14). Đang diễn ra: Thông tin điều hành, Kết thúc Tour. Đã kết thúc: Đóng Tour, khóa khi chưa có quyết toán hiện hành (W77). Đã đóng: Mở lại Tour, chỉ người phụ trách hồ sơ thấy; hồ sơ chỉ đọc.

**Banner Chương trình có thay đổi (W08)** hiện ngay dưới header trên mọi tab khi có thay đổi chưa áp dụng (L1.5).

Số trên tab chỉ báo việc cần làm. Hệ thống tính lại sau mỗi lần lưu:

| Tab | Số hiển thị | Màu |
|---|---|---|
| Dịch vụ & checklist | Công việc hoàn tất / tổng công việc đang áp dụng | Xanh lá khi đủ |
| Đặt dịch vụ | Số hạng mục Cần đặt, Cần đặt lại, Xác nhận một phần, Cần điều chỉnh hoặc Cần hủy. Hạng mục Chờ Kinh doanh không được tính | Vàng; đỏ khi Booking đã hủy |
| Khách đoàn | Số khách có cảnh báo giấy tờ hoặc thiếu trường bắt buộc | Vàng |
| Nhật ký & sự cố | Số sự cố Đang xử lý | Đỏ |
| Quyết toán | Biểu tượng khóa khi hồ sơ chưa ở trạng thái Đã kết thúc | Xám |

### 2.2. Vòng đời hồ sơ Tour

| Từ | Đến | Sự kiện và tác nhân | Điều kiện | Tác động | Ngoại lệ |
|---|---|---|---|---|---|
| (DH07) | Mới tạo | Điều hành tạo hồ sơ từ Booking | Booking Hiệu lực và chưa có hồ sơ | Sinh Tour Code, hạng mục dịch vụ và checklist | Thuộc DH07 |
| Mới tạo | Đang diễn ra | Điều hành bấm Bắt đầu Tour (W03) | Booking không ở trạng thái Đã hủy | Ghi thời điểm bắt đầu và người thao tác. Hộp thoại liệt kê mục chưa sẵn sàng nhưng không chặn | Booking đã hủy thì nút khóa (W06) |
| Đang diễn ra | Đã kết thúc | Điều hành bấm Kết thúc Tour (W05) | Thời điểm kết thúc không sớm hơn thời điểm bắt đầu | Ghi thời điểm kết thúc; mở tab Quyết toán | — |
| Mới tạo | Đã kết thúc | Điều hành bấm Kết thúc hồ sơ (R14) | Booking đã hủy; mọi lần đặt còn hiệu lực đã được gửi yêu cầu hủy | Lý do kết thúc là “Booking đã hủy”; mở Quyết toán để ghi phí hủy | Nút khóa và hiện lý do khi còn lần đặt chưa gửi hủy |
| Đã kết thúc | (dấu mốc) Đã quyết toán | Kế toán bấm Lưu quyết toán (W72) | Đủ trường bắt buộc của quyết toán | Tạo phiên bản quyết toán; hiện nút Đóng Tour | Lưu lỗi: giữ dữ liệu nhập |
| Đã kết thúc | Đã đóng | Điều hành bấm Đóng Tour (W74) | Có quyết toán hiện hành (R16) | Khóa hồ sơ, cập nhật lịch sử khách ở KD04.2 | Chưa có quyết toán hiện hành: nút khóa (W77) |
| Đã đóng | Đã kết thúc | Điều hành phụ trách bấm Mở lại Tour (W76) | Nhập lý do | Gắn chỉ báo Đã mở lại; quyết toán cũ chuyển sang chỉ xem; KD04.2 hiện Đang cập nhật | — |

### 2.3. Trạng thái của các đối tượng con

| Đối tượng | Giá trị | Cách có giá trị |
|---|---|---|
| Hạng mục dịch vụ | Cần đặt, Chờ kết quả, Xác nhận một phần, Cần đặt lại, Chờ Kinh doanh, Cần điều chỉnh, Cần hủy, Đã xác nhận, Đã hủy | Hệ thống tính từ các lần đặt, yêu cầu đổi lịch trình và thay đổi chương trình (R02); người dùng không chọn trực tiếp |
| Chỉ báo phụ của hạng mục | Yêu cầu hủy đang chờ; Điều chỉnh đang chờ; Gửi lỗi; x ngày chưa phản hồi; Quá hạn phản hồi; Chờ áp dụng thay đổi; Theo thay đổi vN (giữ đến khi hạng mục Đã xác nhận hoặc Đã hủy) | R04, R07, R18, R19 |
| Lần đặt dịch vụ | Đã gửi, Đã xác nhận, Không đáp ứng, Đã hủy | Có khi gửi email thành công; kết quả do Điều hành ghi |
| Yêu cầu đổi lịch trình | Chờ Kinh doanh, Đã xử lý, Đã rút | Điều hành gửi; tự chuyển Đã xử lý khi Điều hành áp dụng thay đổi chương trình có chạm tới hạng mục; Điều hành rút (R18) |
| Thay đổi chương trình | Chờ áp dụng, Đã áp dụng, Đã thay thế | Kinh doanh gửi từ màn Kinh doanh; Điều hành áp dụng; phiên bản mới gửi trước khi áp dụng thì thay thế bản đang chờ (R19) |
| Công việc checklist | Chưa làm, Đang làm, Hoàn tất; chỉ báo Quá hạn | Điều hành cập nhật hoặc hệ thống tự hoàn tất theo sự kiện (R03) |
| Sự cố | Đang xử lý, Đã xử lý | Có kết quả thì là Đã xử lý |
| Chi phí phát sinh | Chưa ghi công nợ, Đã ghi công nợ | Tính từ liên kết với khoản công nợ ở KT01 |
| Phiên bản quyết toán | Đang soạn, Hiện hành, Trước mở lại | R16 |

### 2.4. Quy ước giao diện và xử lý dùng chung

- **Kiểu thao tác.**
  - *Trên bảng:* lọc, chọn dòng và nút trên dòng. Nút trên dòng truyền đúng ID của dòng. Bộ lọc nhanh dạng chip có số đếm và áp dụng ngay.
  - *Bảng trượt* (bên phải, rộng 600 px; 760 px khi xem email nhiều NCC): xem hoặc sửa một hạng mục, hoặc kiểm tra nội dung trước khi gửi.
  - *Form tại tab:* thay đổi nhiều dòng có nút lưu chung (phân phòng, quyết toán).
  - *Hộp thoại:* thao tác có hệ quả lớn (bắt đầu, kết thúc, đóng, mở lại Tour, bỏ dịch vụ, nhập Excel).
- **Một thao tác, một chỗ bấm.** Ở mỗi trạng thái màn hình, mỗi thao tác chỉ có một điểm bấm. Thông tin đã có ở header (Booking, ngôn ngữ phục vụ, người phụ trách) không lặp lại trong tab. Khi chọn nhiều dòng, nút và ô chọn trên dòng tạm ẩn; thanh hàng loạt là nơi thao tác duy nhất.
- **Trường điền sẵn** có nhãn nhỏ màu xanh ngọc (Tự điền, Từ Booking, DH03, Gợi ý). Trường chỉ đọc có viền nét đứt.
- **Tải.** Khi đang tải hiện khung chờ. Lỗi tải hiện nút Thử lại. Không có quyền hoặc không tìm thấy hiện W07.
- **Bảng rỗng.** Phân biệt “Chưa có dữ liệu” với “Không có kết quả phù hợp”; trường hợp sau có nút Xóa bộ lọc.
- **Bảng trượt và hộp thoại.** Bảng phía sau giữ bộ lọc, dòng đang chọn và vị trí cuộn. Khi đóng có thay đổi chưa lưu, hỏi Tiếp tục chỉnh sửa hoặc Bỏ thay đổi.
- **Lưu.** Nút đổi thành Đang lưu… hoặc Đang gửi… và bị khóa để chống bấm lặp. Thành công thì đóng bảng trượt, cập nhật dòng tại chỗ và hiện thông báo ngắn ở góc phải dưới trong 5 giây; nếu dòng ra khỏi bộ lọc, giữ bộ lọc và thông báo có thêm liên kết Xem dòng. Lỗi thì giữ dữ liệu nhập, báo lỗi cạnh trường hoặc ở đầu form.
- **Cập nhật đồng thời.** Mỗi bản ghi có số phiên bản. Nếu bản ghi đã bị sửa ở phiên khác, từ chối lưu, hiện giá trị mới và cho chọn Tải lại hoặc Giữ bản của tôi rồi lưu lại. Nếu hồ sơ vừa đóng ở phiên khác, dừng ghi và tải chế độ chỉ đọc.
- **Tiền và ngày.** Tiền hiển thị kèm loại tiền (₫, USD…) và phân cách hàng nghìn bằng dấu chấm. Ngày hiển thị dd/mm/yyyy, giờ hh:mm theo múi giờ vận hành Asia/Ho_Chi_Minh.
- **Lịch sử.** Mọi thay đổi trạng thái, gửi email, sửa kết quả, phân công, quyết toán, đóng và mở lại đều lưu người thao tác, thời điểm, giá trị trước và sau, và lý do nếu có.

---

## 3. Luồng thao tác kèm wireframe

Mỗi luồng có mã L, ngoại lệ có mã E. Mỗi bước ghi theo dạng **mã W · chỗ bấm**, sau đó là thao tác của người dùng và phản hồi của hệ thống. Hình wireframe nằm ngay dưới bước.

### 3.1. DH08.1 · Tổng quan và trạng thái (TN05.03, TN08.01 · SYS05.04, SYS08.03, SYS08.07)

**L1.1 Mở hồ sơ.** *Điều kiện:* người dùng có quyền xem.

1. **W01 · Tour Code ở DH07 hoặc liên kết ở màn khác.** Hệ thống mở đúng hồ sơ và đúng tab đích, tải header và Tổng quan. Trước khởi hành, Tổng quan chỉ có hai khối:
   - **Việc cần làm trước khởi hành.** Chỉ liệt kê mục chưa đạt theo R01. Mỗi mục một dòng: tên mục, mô tả ngắn và một nút đi tới đúng tab và bộ lọc. Các mục đã đạt gộp thành một dòng “✓ Đã xong: …”. Số trên tiêu đề khối là số mục chưa đạt.
   - **Lịch trình.** Mỗi ngày một dòng gồm số ngày, ngày và tuyến. Booking mở từ liên kết ở header; chuyến bay, yêu cầu riêng và cơ cấu phòng xem ở tab Khách đoàn.
2. **W01 → W20 · Nút trên dòng của khối Việc cần làm.** Tab đích mở với bộ lọc tương ứng: Đặt dịch vụ mở DH08.3 lọc Cần đặt; Xem khách mở DH08.4 lọc Cần kiểm tra giấy tờ.

   ![W01 · Tổng quan hồ sơ trước khởi hành](wireframes/W01.png)

*Kết quả:* thấy ngay trạng thái và việc còn thiếu mà không phải mở từng tab.

**L1.2 Đổi người phụ trách và ngôn ngữ phục vụ.**

1. **W02 · Nút Thông tin điều hành ở header → bảng trượt.** Bảng trượt điền sẵn người phụ trách hiện tại và ngôn ngữ phục vụ lấy từ Booking. Điều hành chọn người mới từ DH06 (nhóm Điều hành, đang cho phép nhận phân công), đổi ngôn ngữ, ghi chú nếu cần, rồi bấm Lưu thay đổi.

   ![W02 · Đổi người phụ trách và ngôn ngữ phục vụ](wireframes/W02.png)

2. **W02a · Header và thông báo ngắn.** Hệ thống kiểm tra người phụ trách hợp lệ, cập nhật header, gửi thông báo cho người được giao và ghi lịch sử. Nếu đây là lần giao đầu (hồ sơ tự tạo chưa có người phụ trách), các công việc có thuộc tính Giao người phụ trách mà chưa có người thực hiện được điền người này (RSD DH01 R05); đổi người về sau không đổi người thực hiện của công việc.

   ![W02a · Đã đổi người phụ trách](wireframes/W02a.png)

*Kết quả:* header cập nhật ngay. Nếu không đổi giá trị nào, hệ thống giữ nguyên và không ghi lịch sử.

**L1.3 Bắt đầu Tour.**

1. **W03 · Nút Bắt đầu Tour ở header → hộp thoại.** Hộp thoại điền sẵn thời điểm hiện tại và liệt kê mục chưa sẵn sàng theo R01; liên kết Xem các mục mở tab tương ứng. Điều hành giữ hoặc sửa thời điểm, rồi bấm Vẫn bắt đầu Tour (hoặc Bắt đầu Tour khi không còn mục thiếu). Hộp thoại không chặn.

   ![W03 · Xác nhận bắt đầu Tour](wireframes/W03.png)

2. **W04 · Tổng quan khi Tour đang diễn ra.** Hồ sơ chuyển Đang diễn ra; Tổng quan đổi bố cục:
   - **Khối Hôm nay.** Lịch dịch vụ và nhân sự của ngày hiện tại. Tiêu đề khối có ba nút ghi nhanh: + Nhật ký, + Sự cố, + Chi phí. Mỗi nút mở bảng trượt của tab tương ứng (W56, W61) ngay trên Tổng quan; lưu xong vẫn ở Tổng quan. Dòng cuối khối ghi số sự cố đang mở và thời điểm nhật ký mới nhất.
   - **Khối Lịch trình.** Ngày hiện tại được tô nền và gắn nhãn Hôm nay; các ngày đã qua hiện màu nhạt.

   ![W04 · Tổng quan khi Tour đang diễn ra](wireframes/W04.png)

**L1.4 Kết thúc Tour.**

1. **W05 · Nút Kết thúc Tour ở header → hộp thoại.** Điều hành kiểm tra thời điểm rồi bấm Kết thúc Tour. Hệ thống kiểm tra thời điểm, chuyển Đã kết thúc và mở khóa tab Quyết toán ở bước 1.

   ![W05 · Xác nhận kết thúc Tour](wireframes/W05.png)

**L1.5 Nhận và áp dụng thay đổi chương trình.** *Điều kiện:* Kinh doanh sửa lịch trình ở màn Kinh doanh rồi bấm Gửi Điều hành. Thay đổi có thể do khách hoặc đại lý yêu cầu, do Kinh doanh điều chỉnh chương trình, hoặc để xử lý yêu cầu đổi lịch trình của Điều hành (L3.12). Không nhất thiết phải có NCC không đáp ứng.

1. **W08 · Banner vàng dưới header, trên mọi tab.** Điều hành phụ trách nhận thông báo. Banner ghi phiên bản, người gửi, thời điểm, số thay đổi và nút Xem thay đổi; banner mất khi thay đổi đã được áp dụng. Hồ sơ giữ nguyên dữ liệu; hạng mục bị thay đổi chạm tới tạm khóa đặt (R19).

   ![W08 · Thông báo chương trình có thay đổi](wireframes/W08.png)

2. **W09 · Nút Xem thay đổi → bảng trượt rộng.** Hệ thống so sánh **bản cũ** (phiên bản đang áp dụng cho hồ sơ) với **bản mới** và liệt kê từng thay đổi theo ngày (Thêm, Bỏ, Đổi dịch vụ, Đổi ngày, Đổi số lượng, Đổi yêu cầu). Mỗi dòng có giá trị bản cũ, bản mới và cột “Khi áp dụng vào hồ sơ”. Bảng trượt hiện ghi chú của Kinh doanh và những gì không đổi. Điều hành bấm Áp dụng thay đổi ở chân bảng trượt; hệ thống áp dụng cả phiên bản trong một lần.

   ![W09 · Xem thay đổi chương trình](wireframes/W09.png)

3. **W39 · Banner kết quả xanh trên DH08.3.** Hệ thống cập nhật hồ sơ theo R19 rồi chuyển sang tab Đặt dịch vụ. Banner nêu số dịch vụ cần đặt, cần điều chỉnh, cần hủy và đã bỏ. Dòng bị ảnh hưởng có chỉ báo Theo thay đổi vN và nút xử lý trên dòng: Đặt dịch vụ, Gửi điều chỉnh (W35, L3.11) hoặc Gửi yêu cầu hủy. Email cho NCC đã soạn sẵn, không email nào tự gửi.

   ![W39 · Kết quả sau khi áp dụng thay đổi](wireframes/W39.png)

4. **W39a · Nút Gửi yêu cầu hủy trên dòng Cần hủy → bảng trượt.** Lý do điền sẵn từ thay đổi chương trình, email hủy soạn sẵn. Điều hành kiểm tra rồi bấm Gửi yêu cầu hủy, hoặc Để sau.

   ![W39a · Gửi yêu cầu hủy theo thay đổi](wireframes/W39a.png)

5. **W39b · Dòng cập nhật, thông báo ngắn.** Dịch vụ mới chuyển Chờ kết quả. Dịch vụ đã gửi hủy về Đã xác nhận kèm chỉ báo Yêu cầu hủy đang chờ và nút Ghi kết quả hủy. Kết quả từ NCC ghi như L3.5 hoặc L3.8.

   ![W39b · Sau khi gửi email cho NCC](wireframes/W39b.png)

*Kết quả:* hồ sơ chạy theo phiên bản chương trình mới. Lịch trình Tổng quan, hạng mục, checklist và phân phòng được cập nhật. Kinh doanh nhận thông báo đã áp dụng.

**Ngoại lệ**

- **E1.1 · W07.** Không có quyền, không tìm thấy hồ sơ hoặc không tải được: thay toàn bộ vùng nội dung, không tải dữ liệu hồ sơ, hiện lý do và nút Về danh sách hồ sơ Tour. Khi lỗi tải, có thêm nút Thử lại.

  ![W07 · Không mở được hồ sơ](wireframes/W07.png)

- **E1.2 · W06.** Booking đã hủy: xử lý theo L3.9 và R14.
- **E1.3.** Người phụ trách được chọn đã bị tắt quyền nhận phân công ở phiên khác: báo lỗi cạnh trường và yêu cầu chọn lại.
- **E1.4.** Thời điểm bắt đầu ở tương lai hoặc thời điểm kết thúc sớm hơn thời điểm bắt đầu: báo lỗi cạnh trường, không lưu.
- **E1.5.** Hồ sơ vừa được chuyển trạng thái ở phiên khác: từ chối thao tác, tải lại header và báo “Hồ sơ đã được cập nhật bởi …”.
- **E1.6.** Có phiên bản mới hơn khi phiên bản đang chờ chưa áp dụng: phiên bản đang chờ chuyển Đã thay thế. Banner và bảng trượt chỉ hiện phiên bản mới nhất, so với bản cũ đang áp dụng cho hồ sơ.
- **E1.7.** Hồ sơ vừa đổi ở phiên khác trong lúc đang xem thay đổi (ví dụ một dịch vụ vừa được gửi đặt): khi bấm Áp dụng, hệ thống tính lại ảnh hưởng, hiện các dòng đã đổi và yêu cầu bấm Áp dụng lần nữa.
- **E1.8.** Áp dụng lỗi: không áp dụng phần nào, hồ sơ giữ nguyên, banner vẫn còn và có nút Thử lại.
- **E1.9.** Thay đổi chạm tới ngày đã qua khi Tour đang diễn ra: dòng đó hiện “Không áp dụng được, ngày đã qua”. Nút Áp dụng thay đổi bị khóa; Kinh doanh nhận thông báo để sửa và gửi phiên bản mới.
- **E1.10.** Hồ sơ đã đóng: không nhận thay đổi chương trình; Kinh doanh được báo hồ sơ đã đóng.

### 3.2. DH08.2 · Dịch vụ và checklist (TN05.04 · SYS05.05, SYS05.06)

**L2.1 Xem và lọc.** **W10 · Chip lọc, ô tìm, chọn ngày trên đầu bảng.** Danh sách gộp dịch vụ và công việc, nhóm theo Trước Tour và từng ngày Tour; nhóm được giữ khi lọc. Chip gồm Tất cả, Việc của tôi, Chưa xong, Quá hạn. Bộ lọc áp dụng ngay. Công việc chưa giao hiện ô Chọn người viền nét đứt nên dễ nhận ra, không cần bộ lọc riêng.

**L2.2 Phân công và đổi tiến độ ngay trên dòng.** **W10 · Ô chọn tại chỗ ở cột Người thực hiện và cột Tiến độ.** Điều hành bấm ô, chọn giá trị; hệ thống lưu ngay, không mở form, và số trên tab cập nhật. Ô Người thực hiện chỉ liệt kê nhân sự đang cho phép nhận phân công. Lưu lỗi thì ô trả về giá trị cũ và báo lỗi. Đây là cách duy nhất để phân công và đổi tiến độ trên danh sách; bảng trượt W12 dùng khi cần sửa nhiều trường cùng lúc.

![W10 · Danh sách dịch vụ và checklist](wireframes/W10.png)

**L2.3 Phân công và sửa công việc.**

1. **W12 · Bấm tên công việc → bảng trượt.** Dòng đầu ghi mẫu và phiên bản đã sinh công việc (ví dụ Inbound tiêu chuẩn v4) và sự kiện tự hoàn tất. Hạn hoàn tất điền sẵn theo mẫu, kèm nhãn cách tính (ví dụ 7 ngày trước Khởi hành). Hướng dẫn thực hiện lấy từ mẫu, chỉ đọc. Cuối bảng trượt có lịch sử công việc.
2. **W12 → W10 · Nút Lưu.** Điều hành chọn người thực hiện, sửa nội dung, hạn, tiến độ hoặc ghi chú, rồi bấm Lưu. Hệ thống kiểm tra nhân sự hợp lệ; bảng trượt đóng, dòng cập nhật tại chỗ, kèm thông báo ngắn.

   ![W12 · Chi tiết công việc](wireframes/W12.png)

**L2.4 Thao tác hàng loạt.** **W11 · Ô chọn đầu dòng công việc → thanh hàng loạt.** Chọn nhiều dòng công việc trong trang đang xem (dòng dịch vụ không có ô chọn). Khi đã chọn, ô chọn tại chỗ và nút trên các dòng tạm ẩn; thanh hàng loạt hiện ô Giao cho và ô Tiến độ. Chọn giá trị rồi bấm Áp dụng. Hệ thống áp dụng cho từng dòng hợp lệ, thông báo dạng “Đã phân công 3/3”, báo số dòng bị bỏ qua kèm lý do và giữ chọn các dòng lỗi (R09).

![W11 · Giao việc hoặc đổi tiến độ hàng loạt](wireframes/W11.png)

**L2.5 Thêm dịch vụ.**

1. **W13 · Nút + Dịch vụ → bảng trượt.** Chọn ngày và dịch vụ trong danh mục. Đơn vị, giá tham chiếu và số lượng điền sẵn (số lượng mặc định bằng số khách).
2. **W13 · Nút Lưu dịch vụ, hoặc Lưu và đặt ngay** để chuyển thẳng sang W24.

   ![W13 · Thêm dịch vụ](wireframes/W13.png)

*Kết quả:* hạng mục Cần đặt. Hệ thống sinh các việc theo dịch vụ cùng loại của mẫu mà hồ sơ đã dùng khi tạo, ở phiên bản hiện hành của mẫu, với hạn tính theo ngày sử dụng của hạng mục mới (RSD DH01 L5.2, R07). Việc cả hồ sơ không sinh lại.

**L2.6 Bỏ dịch vụ.** **W14 · Menu ⋯ trên dòng → hộp thoại.** Nhập lý do rồi bấm Bỏ dịch vụ. Hệ thống kiểm tra lại hạng mục chưa có lần đặt và chưa liên kết công nợ, rồi bỏ hạng mục cùng công việc chỉ gắn với nó và tính lại tiến độ.

![W14 · Bỏ dịch vụ](wireframes/W14.png)

**L2.7 Đặt từ dòng.** **W10 → W24 · Nút Đặt dịch vụ trên dòng dịch vụ Cần đặt.** Một lần bấm: DH08.3 mở với bảng trượt email đã soạn sẵn cho đúng hạng mục.

**Ngoại lệ**

- **E2.1 · W15.** Dịch vụ đã có lần đặt hoặc liên kết công nợ: hộp thoại chặn bỏ, hiện lý do và nút Mở lần đặt để hủy. Nút này mở DH08.3 với bảng trượt lịch sử (W29) của hạng mục.

  ![W15 · Chặn bỏ dịch vụ đã đặt](wireframes/W15.png)

- **E2.2.** Nhân sự được chọn không còn được phép nhận phân công: báo lỗi cạnh trường; với thao tác hàng loạt, ghi dòng bị bỏ qua.
- **E2.3.** Ngày dịch vụ nằm ngoài thời gian Tour hoặc số lượng ≤ 0: báo lỗi cạnh trường.

### 3.3. DH08.3 · Đặt dịch vụ (TN06.01–TN06.04 · SYS06.01–SYS06.06)

**L3.1 Xem việc cần làm.** **W20 · Chip trạng thái có số đếm, bảng.** Chip gồm Tất cả, Cần đặt, Chờ kết quả, Cần đặt lại, Chờ Kinh doanh, Cần điều chỉnh / hủy, Đã xác nhận, Đã hủy; bấm chip là lọc ngay. Mỗi dòng gồm ngày dùng, dịch vụ, NCC, số lượng, trạng thái, tóm tắt lần đặt gần nhất (thời điểm gửi, số ngày chưa phản hồi, mã xác nhận hoặc lý do) và một nút thao tác chính theo trạng thái (R05).

![W20 · Danh sách đặt dịch vụ](wireframes/W20.png)

**L3.2 Đặt nhiều hạng mục cùng lúc.**

1. **W21 · Ô chọn đầu dòng → thanh thao tác.** Chọn các dòng Cần đặt. Thanh thao tác cho biết số email sẽ tạo sau khi gộp theo NCC (R04); dòng không đủ điều kiện bị loại kèm lý do. Bấm Soạn email đặt (n NCC).

   ![W21 · Chọn nhiều dịch vụ để đặt](wireframes/W21.png)

2. **W22 · Bảng trượt rộng: danh sách NCC bên trái, email bên phải.** Email soạn sẵn theo mẫu; yêu cầu riêng của khách được chèn tự động và tô vàng (R06). Mỗi NCC có nhãn Sẵn sàng gửi hoặc Cần bổ sung. Người dùng bấm từng NCC để xem, sửa trực tiếp nội dung nếu cần, rồi bấm Gửi n email ở chân bảng trượt.

   ![W22 · Kiểm tra email đặt theo NCC](wireframes/W22.png)

3. **W23 · Banner kết quả trên bảng.** Hệ thống báo kết quả theo từng NCC. Phần gửi thành công tạo lần đặt và chuyển Chờ kết quả. Phần lỗi giữ nguyên email; dòng lỗi chỉ hiện lý do, không có nút riêng. Banner có nút Gửi lại phần lỗi (chỉ gửi các NCC lỗi) và Sửa người nhận.

   ![W23 · Kết quả gửi hàng loạt](wireframes/W23.png)

**L3.3 Đặt một hạng mục.**

1. **W24 · Nút Đặt dịch vụ trên dòng → bảng trượt.** Bảng trượt mở thẳng ở bước kiểm tra email, mẫu tự chọn: người nhận lấy từ DH03, tiêu đề có Tour Code, nội dung có ngày, số lượng, yêu cầu dịch vụ và yêu cầu riêng. Kiểm tra, sửa nếu cần, rồi bấm Gửi email.

   ![W24 · Đặt một dịch vụ](wireframes/W24.png)

2. **W24a · Dòng cập nhật tại chỗ, thông báo ngắn có liên kết Xem email đã gửi.** Gửi thành công tạo một lần đặt Đã gửi, lưu cùng bản email đã gửi. Dòng chuyển Chờ kết quả, ghi thời điểm gửi và người nhận; số trên tab giảm. Khi NCC phản hồi, bấm Ghi kết quả (L3.5).

   ![W24a · Đã gửi email đặt](wireframes/W24a.png)

**L3.4 Hạng mục chưa có NCC.** **W25 · Cùng bảng trượt đặt, khi hạng mục chưa có NCC.** Bảng trượt hiện danh sách NCC đang được phép sử dụng, lọc theo loại dịch vụ, khu vực và bảng giá còn hiệu lực ở ngày dùng, có giá tham chiếu, tỷ lệ xác nhận và nhãn Gợi ý. Chọn NCC thì NCC được gắn cho hạng mục, giá tham chiếu cập nhật và email tự soạn ngay bên dưới.

![W25 · Chọn NCC cho dịch vụ](wireframes/W25.png)

**L3.5 Ghi kết quả Đã xác nhận.**

1. **W26 · Nút Ghi kết quả trên dòng → bảng trượt.** Chọn Đã xác nhận. Số lượng xác nhận, giá NCC và loại tiền điền sẵn theo lần đặt và giá tham chiếu; bảng trượt hiện so sánh với giá tham chiếu. Nhập mã xác nhận nếu NCC cấp, sửa giá nếu khác, rồi bấm Lưu kết quả.

   ![W26 · Ghi NCC đã xác nhận](wireframes/W26.png)

2. **W26a · Dòng cập nhật tại chỗ, thông báo ngắn.** Hạng mục tính lại theo R02; dòng chuyển Đã xác nhận, kèm mã và giá.

   ![W26a · Đã lưu kết quả xác nhận](wireframes/W26a.png)

*Kết quả:* hạng mục Đã xác nhận và vào KT01.2 · Chờ ghi phải trả; công việc đặt dịch vụ liên quan tự Hoàn tất (R03). Giá bán đã chốt với khách không đổi.

**L3.6 Xác nhận một phần.** **W27 · Cùng bảng trượt Ghi kết quả.** Khi số lượng xác nhận nhỏ hơn số yêu cầu, hệ thống hiện ngay phần còn thiếu. Sau khi lưu, hạng mục chuyển Xác nhận một phần và nút trên dòng là Đặt phần còn thiếu. Nút này mở email đã điền đúng số còn thiếu, gửi được cho cùng NCC hoặc NCC khác.

![W27 · Ghi xác nhận một phần hoặc không đáp ứng](wireframes/W27.png)

**L3.7 Không đáp ứng và đặt lại.**

1. **W27 · Cùng bảng trượt Ghi kết quả.** Chọn Không đáp ứng, nhập lý do rồi lưu. Hạng mục chuyển Cần đặt lại; nút trên dòng là Đặt lại.
2. **W28 · Nút Đặt lại trên dòng → bảng trượt.** Bảng trượt hiện lý do của lần trước và danh sách NCC thay thế cùng loại, khu vực, hạng sao, kèm chênh lệch giá tham chiếu. Mặc định chọn NCC rẻ nhất có tỷ lệ xác nhận cao. Email tự soạn và đổi theo NCC đã chọn. Chân bảng trượt luôn có nút Báo Kinh doanh (L3.12) cho trường hợp không có NCC phù hợp hoặc cần sửa lịch trình. Khi danh sách NCC thay thế rỗng, bảng trượt hiện “Không còn NCC tương đương” và Báo Kinh doanh trở thành nút chính.

   ![W28 · Đặt lại với NCC khác](wireframes/W28.png)

3. **W28 → W29 · Nút Gửi email đặt lại.** Hệ thống tạo lần đặt mới trên cùng hạng mục và giữ lịch sử lần đặt cũ (L3.10).

**L3.8 Hủy một lần đặt.**

1. **W30 · Nút Hủy lần đặt trong lịch sử (W29) hoặc menu ⋯ trên dòng → bảng trượt.** Nhập lý do; email hủy được soạn sẵn kèm mã xác nhận. Kiểm tra rồi bấm Gửi yêu cầu hủy. Hệ thống lưu email và thời điểm; dòng giữ trạng thái hiện tại và thêm chỉ báo Yêu cầu hủy đang chờ.

   ![W30 · Gửi yêu cầu hủy](wireframes/W30.png)

2. **W31 · Nút Ghi kết quả hủy trên dòng → bảng trượt.** Khi NCC phản hồi, chọn NCC chấp nhận hủy hoặc NCC từ chối hủy. Nhập phí hủy (0 nếu không mất phí), loại tiền, mã hủy, đính kèm phản hồi, rồi bấm Lưu kết quả hủy. Phí hủy được gợi ý sẵn theo chính sách đổi hủy của hợp đồng NCC có kỳ hiệu lực chứa ngày sử dụng (DH03.2), tính theo mốc ứng với ngày gửi hủy; có nhãn Gợi ý và người dùng sửa theo phí NCC báo thực tế. Không có hợp đồng hoặc chính sách phù hợp thì phí mặc định là 0 và hiện ghi chú “Chưa có chính sách đổi hủy áp dụng”.

   ![W31 · Ghi kết quả hủy và phí hủy](wireframes/W31.png)

*Kết quả:* nếu NCC chấp nhận, lần đặt chuyển Đã hủy và phí hủy lớn hơn 0 vào KT01.2. Nếu NCC từ chối, lần đặt giữ kết quả cũ và lịch sử ghi lý do từ chối.

**L3.9 Booking đã hủy: hủy hàng loạt (quyết định Q1B).**

1. **W06 · Banner đỏ trên Tổng quan và DH08.3.** Header có chỉ báo đỏ; banner nêu lý do, số lần đặt còn hiệu lực và số NCC. Tổng quan thay khối Việc cần làm bằng khối Việc cần làm để đóng hồ sơ, gồm 3 bước: gửi yêu cầu hủy, ghi kết quả hủy và phí hủy, kết thúc hồ sơ. Khối Lịch trình bị ẩn. Bắt đầu Tour và các nút đặt bị khóa; nút Kết thúc hồ sơ khóa và có chú thích lý do cho đến khi đủ điều kiện R14. Điều hành bấm Soạn email hủy (n NCC) ở bước 1.

   ![W06 · Hồ sơ có Booking đã hủy](wireframes/W06.png)

2. **W32 · Bảng trượt rộng.** Hệ thống soạn sẵn một email hủy cho mỗi NCC, gộp mọi lần đặt Đã gửi hoặc Đã xác nhận của NCC đó. Lý do hủy điền sẵn từ Booking. Điều hành xem, sửa từng email nếu cần, bỏ chọn NCC không muốn gửi, rồi bấm Gửi n email hủy.

   ![W32 · Hủy hàng loạt khi Booking bị hủy](wireframes/W32.png)

3. **W23, W31.** Kết quả gửi hiện theo từng NCC như W23. Khi có phản hồi, ghi kết quả và phí hủy cho từng lần đặt như W31.

*Kết quả:* hạng mục Cần đặt hoặc Cần đặt lại (chưa từng gửi NCC) tự chuyển Đã hủy và không gửi email. Khi mọi lần đặt còn hiệu lực đã được gửi yêu cầu hủy, nút Kết thúc hồ sơ mở (R14).

**L3.10 Xem lịch sử.** **W29 · Bấm tên dịch vụ → bảng trượt.** Dòng thời gian các lần đặt gồm NCC, thời điểm, người gửi, bản email đã gửi, kết quả, mã, giá và phí hủy. Các nút Xem email đã gửi, Ghi kết quả, Hủy lần đặt chỉ hiện khi hợp lệ.

![W29 · Lịch sử lần đặt](wireframes/W29.png)

**L3.11 Gửi điều chỉnh khi dữ liệu thay đổi sau lần đặt.** **W35 · Chip Cần điều chỉnh / hủy; nút Gửi điều chỉnh trên dòng → bảng trượt.** Khi yêu cầu riêng, giờ bay hoặc số khách đổi sau khi đã gửi NCC (R07), hoặc khi áp dụng thay đổi chương trình (R19), dịch vụ chuyển **Cần điều chỉnh**. Bảng trượt hiện bảng so sánh “Đã gửi NCC” và “Hiện tại”, cùng email điều chỉnh đã soạn sẵn. Bấm Gửi điều chỉnh: dịch vụ trở về trạng thái trước đó kèm chỉ báo Điều chỉnh đang chờ cho tới khi ghi kết quả, và hệ thống lưu bản chụp mới. Chọn Không cần gửi thì phải nhập lý do, và dịch vụ trở về trạng thái trước đó ngay.

![W35 · Gửi điều chỉnh cho NCC](wireframes/W35.png)

**L3.12 Báo Kinh doanh đổi lịch trình.** *Điều kiện:* hạng mục Cần đặt lại hoặc Xác nhận một phần, và không có NCC tương đương, hoặc phải sửa lịch trình (đổi ngày, đổi dịch vụ hoặc hạng, bỏ dịch vụ).

1. **W36 · Nút Báo Kinh doanh ở chân bảng trượt Đặt lại (W28) → bảng trượt yêu cầu.** Hệ thống điền sẵn hạng mục, ngày sử dụng, số lượng, các NCC đã thử kèm lý do không đáp ứng, người nhận (Kinh doanh phụ trách Booking) và hạn phản hồi. Điều hành chọn loại đề xuất, ghi nội dung đề xuất, kiểm tra hạn, rồi bấm Gửi Kinh doanh.

   ![W36 · Báo Kinh doanh đổi lịch trình](wireframes/W36.png)

2. **W37 · Chip Chờ Kinh doanh; nút Xem yêu cầu trên dòng.** Hạng mục chuyển **Chờ Kinh doanh**, dòng ghi người nhận và hạn phản hồi; quá hạn có chỉ báo đỏ. Bấm Xem yêu cầu để xem, nhắc lại hoặc rút. Kinh doanh nhận thông báo trong hệ thống và email nội bộ, có liên kết mở Booking ở màn Kinh doanh.

   ![W37 · Dịch vụ đang chờ Kinh doanh](wireframes/W37.png)

3. **Ngoài DH08; dòng vẫn như W37.** Kinh doanh sửa lịch trình ở màn Kinh doanh (KD08, ngoài tài liệu này) rồi bấm Gửi Điều hành. Kinh doanh không phản hồi trong DH08.
4. **W08 → W09.** Hồ sơ hiện thông báo Chương trình có thay đổi; Điều hành xem và áp dụng như L1.5. Khi thay đổi có chạm tới hạng mục này, yêu cầu đổi lịch trình tự chuyển Đã xử lý.
5. **W39.** Hạng mục đổi sang dịch vụ và NCC mới, trạng thái **Cần đặt**, chỉ báo Theo thay đổi vN. Điều hành bấm Đặt dịch vụ trên dòng để mở email đã soạn sẵn (W24).
6. **W39b.** Gửi thành công: hạng mục chuyển **Chờ kết quả**; lần đặt mới nối tiếp các lần đặt cũ trong lịch sử. Từ đây hạng mục đi tiếp luồng ghi kết quả bình thường (L3.5–L3.7).

*Kết quả:* trạng thái hạng mục đi theo chuỗi Cần đặt lại → Chờ Kinh doanh → Cần đặt (sau khi áp dụng thay đổi) → Chờ kết quả. Lịch sử lần đặt cũ được giữ. Kinh doanh thấy cùng trạng thái khi mở DH08.3.

**Ngoại lệ**

- **E3.1 · W33.** Thiếu email đặt dịch vụ của NCC, thiếu mẫu email cho loại dịch vụ hoặc thiếu dữ liệu bắt buộc: banner đỏ trong bảng trượt, lỗi cạnh trường, nút Gửi khóa đến khi đủ dữ liệu. Người dùng nhập email cho lần gửi này và có thể chọn lưu vào DH03 nếu có quyền. Khi thiếu mẫu, có nút Soạn không theo mẫu. Thiếu giá tham chiếu chỉ là cảnh báo.

  ![W33 · Thiếu thông tin để gửi email](wireframes/W33.png)

- **E3.2 · W23.** Gửi thất bại: không tạo lần đặt, giữ nội dung, hiện mã lỗi dễ hiểu và nút Gửi lại.
- **E3.3 · W34.** Chưa xác định email đã gửi hay chưa: banner vàng và khối Đang kiểm tra trong bảng trượt, nút Gửi email khóa. Hệ thống tra trạng thái theo mã gửi và tự kiểm tra lại theo R08; người dùng chờ hoặc đóng bảng trượt. Kết quả cuối cùng hiện tại dòng và bằng thông báo ngắn.

  ![W34 · Chưa rõ email đã gửi chưa](wireframes/W34.png)

- **E3.4.** Đổi NCC sau khi đã sửa email: người nhận và các trường lấy từ NCC được cập nhật, phần nội dung người dùng tự thêm được giữ.
- **E3.5.** Số lượng xác nhận ≤ 0 hoặc lớn hơn số yêu cầu; giá hoặc phí hủy âm; thiếu loại tiền: báo lỗi cạnh trường.
- **E3.6.** Booking đã hủy: nút Đặt dịch vụ, Đặt lại và Soạn email đặt bị khóa, kèm chú thích “Booking đã hủy”. Các nút hủy và ghi kết quả vẫn hoạt động.
- **E3.7.** Sửa kết quả đã lưu: theo R10.
- **E3.8.** Gửi hàng loạt khi một dòng vừa đổi trạng thái ở phiên khác: dòng đó bị loại khỏi lần gửi và kết quả ghi “Đã thay đổi, không gửi”.
- **E3.9 · W36.** Đã có yêu cầu đang mở cho hạng mục: nút Báo Kinh doanh đổi thành Xem yêu cầu, không tạo yêu cầu thứ hai.
- **E3.10.** Booking không có Kinh doanh phụ trách, hoặc người đó không còn hoạt động: trường Gửi cho chuyển thành ô chọn bắt buộc, chỉ liệt kê người dùng vai trò Kinh doanh.
- **E3.11 · W37.** Quá hạn phản hồi: dòng có chỉ báo đỏ Quá hạn phản hồi. Mục Đặt dịch vụ trên Tổng quan ghi “n quá hạn phản hồi”. Hệ thống tự gửi nhắc Kinh doanh một lần khi quá hạn.
- **E3.12.** Gửi yêu cầu bị lỗi: giữ nội dung đã nhập, báo lỗi và cho Gửi lại.
- **E3.13.** Thay đổi chương trình được áp dụng nhưng không chạm tới hạng mục đang Chờ Kinh doanh: yêu cầu giữ nguyên Chờ Kinh doanh. Dòng hiện ghi chú “Phiên bản mới chưa xử lý hạng mục này”; Điều hành nhắc Kinh doanh hoặc rút yêu cầu.
- **E3.14.** NCC cũ báo lại còn chỗ trong lúc chờ Kinh doanh: Điều hành mở Xem yêu cầu, bấm Rút yêu cầu và ghi lý do. Yêu cầu chuyển Đã rút, hạng mục trở về Cần đặt lại; Kinh doanh nhận thông báo yêu cầu đã rút.
- **E3.15.** Booking bị hủy khi đang có yêu cầu mở: yêu cầu tự chuyển Đã rút với lý do “Booking đã hủy”.

### 3.4. DH08.4 · Khách đoàn và phân phòng (TN07.01, TN07.02, TN07.04 · SYS07.01–SYS07.04)

Tab có 4 phần con: Danh sách khách, Yêu cầu riêng, Phân phòng, Pax list và Rooming list.

**L4.1 Kinh doanh nhập khách.**

1. **W40 · Tab con Danh sách khách; chip lọc có số đếm.** Chip gồm Cần kiểm tra giấy tờ, Chưa có chuyến bay, Có yêu cầu riêng; bấm là lọc ngay. Dòng có cảnh báo được tô nền vàng; lý do cảnh báo hiện ngay ở cột Hết hạn hoặc Visa. Số hộ chiếu đã che.

   ![W40 · Danh sách khách](wireframes/W40.png)

2. **W41 · Nút + Thêm khách hoặc tên khách → bảng trượt.** Bảng trượt có 4 nhóm: Cá nhân, Giấy tờ nhập cảnh (hộ chiếu, hạn, visa), Chuyến bay (điền sẵn chuyến bay chung của đoàn), Yêu cầu riêng (chọn nhãn và ghi chú). Bấm Lưu khách. Hệ thống kiểm tra trường bắt buộc và trùng, cảnh báo giấy tờ theo R11, và chạy R07 cho các dịch vụ đã gửi NCC.

   ![W41 · Thông tin một khách](wireframes/W41.png)

**L4.2 Nhập từ Excel.** **W42 · Nút Nhập từ Excel → hộp thoại.** Chọn tệp theo file mẫu. Hệ thống ghép khách theo số hộ chiếu, rồi hiện xem trước gồm số dòng cập nhật, số khách mới và các dòng lỗi kèm lý do. Bấm Nhập n dòng hợp lệ. Dòng lỗi không được nhập; người dùng tải tệp dòng lỗi về để sửa.

![W42 · Nhập danh sách khách từ Excel](wireframes/W42.png)

**L4.3 Gán chuyến bay hoặc yêu cầu riêng cho nhiều khách.** **W43 · Ô chọn khách → thanh thao tác → khung nhập tại chỗ.** Chọn khách. Thanh hàng loạt hiện ngay các ô chiều bay, số hiệu, ngày giờ và sân bay; nhập rồi bấm Áp dụng. Yêu cầu riêng cho nhiều khách thêm trong form từng khách (W41). Hệ thống cập nhật mọi khách đã chọn, tô sáng ô chuyến bay vừa đổi và chạy R07: dịch vụ đón hoặc tiễn đã gửi NCC có chỉ báo Giờ bay thay đổi.

![W43 · Gán chuyến bay cho nhiều khách](wireframes/W43.png)

**L4.4 Xem tổng hợp yêu cầu riêng.** **W44 · Tab con Yêu cầu riêng (chỉ đọc).** Hệ thống gom yêu cầu theo nhóm Ăn uống và Phòng, ghi số lượng và tên khách. Phần xem trước hiển thị đúng câu sẽ được chèn vào email đặt dịch vụ (R06). Danh sách “Đã gửi NCC trước khi yêu cầu thay đổi” hiện dịch vụ Cần điều chỉnh kèm nút Gửi điều chỉnh (mở W35).

![W44 · Tổng hợp yêu cầu riêng](wireframes/W44.png)

**L4.5 Điều hành xếp phòng.**

1. **W45 · Tab con Phân phòng; chip đợt lưu trú; form tại tab.** Chọn đợt lưu trú (mỗi khách sạn hoặc du thuyền một đợt). Bấm Tự xếp theo gợi ý để hệ thống xếp theo cặp khách đăng ký chung phòng và yêu cầu phòng. Điều hành kéo thả để chỉnh, kéo khách từ nhóm Chưa xếp vào phòng. Ô phòng hiện số khách / sức chứa; nhóm Chưa xếp cập nhật ngay; đợt còn thiếu có dấu !.

   ![W45 · Xếp phòng](wireframes/W45.png)

2. **W45a · Nút Sao chép sang đợt khác… → hộp thoại.** Chọn các đợt lưu trú đích. Hộp thoại xem trước số phòng, số khách và đợt bị ghi đè; hệ thống ghép theo hạng phòng, tự đánh số phòng và báo khách chưa xếp. Bấm Sao chép sang n đợt. Kết quả chưa lưu cho tới khi bấm Lưu phân phòng.

   ![W45a · Sao chép phân phòng sang đợt khác](wireframes/W45a.png)

3. **W45b · Nút Lưu phân phòng.** Phân phòng mọi đợt được lưu trong một lần; nút Lưu và Hủy thay đổi khóa lại cho tới khi có sửa mới. Nếu còn khách chưa xếp, thông báo ngắn nêu số khách và liên kết Xem khách chưa xếp.

   ![W45b · Đã lưu phân phòng](wireframes/W45b.png)

**L4.6 Pax list và Rooming list.**

1. **W47 · Tab con Pax list và Rooming list; chip loại tài liệu; chọn mẫu.** Chọn Pax list hoặc Rooming list của từng khách sạn và chọn mẫu. Bảng xem trước đọc dữ liệu đã lưu, đúng mẫu; lịch sử gửi hiện bên dưới. Bấm Tải Excel hoặc Tải PDF.

   ![W47 · Xem Pax list và Rooming list](wireframes/W47.png)

2. **W48 · Nút Gửi cho NCC… → bảng trượt rộng.** Danh sách liệt kê NCC trong Tour; hệ thống chọn sẵn tập cột theo loại NCC và địa chỉ nhận. Bấm tên NCC để xem trước, rồi bấm Gửi n email. Cảnh báo giấy tờ hiện nhưng không chặn.

   ![W48 · Gửi Pax list cho NCC](wireframes/W48.png)

*Kết quả:* mỗi NCC nhận một email riêng kèm tệp đúng tập cột; kết quả gửi theo từng NCC. Lịch sử gửi hiển thị dưới bảng xem trước.

**Ngoại lệ**

- **E4.1 · W40, W41.** Hộ chiếu hết hạn trước ngày bắt đầu Tour cộng 6 tháng, hoặc visa “Cần visa · chưa có”: cảnh báo trên dòng, trong form, ở Tổng quan và khi gửi Pax list. Không chặn lưu hoặc gửi (R11).
- **E4.2.** Thiếu trường bắt buộc (họ, tên, giới tính, ngày sinh, quốc tịch, số hộ chiếu, ngày hết hạn) hoặc ngày sinh sau ngày hiện tại: báo lỗi cạnh trường, không lưu.
- **E4.3 · W42.** Trùng số hộ chiếu trong cùng Tour: khi nhập tay, mở bản ghi hiện có; khi nhập Excel, dòng bị đánh lỗi.
- **E4.4 · W46.** Phòng vượt sức chứa hoặc khách bị xếp hai phòng trong cùng đợt: banner đỏ, phòng lỗi viền đỏ, chỉ rõ phòng và khách; chặn lưu và giữ thay đổi. Người dùng chuyển khách rồi lưu lại.

  ![W46 · Lỗi xếp phòng vượt sức chứa](wireframes/W46.png)

- **E4.5 · W49.** Rooming list của đợt còn khách chưa xếp: không tạo tài liệu, khóa Tải và Gửi, liệt kê khách chưa xếp và có nút Mở phân phòng đợt đó. Pax list không phụ thuộc phân phòng.

  ![W49 · Chưa tạo được Rooming list](wireframes/W49.png)

- **E4.6.** Gửi Pax list lỗi cho một số NCC: xử lý như E3.2 và E3.3, có kết quả theo từng NCC.
- **E4.7.** Số khách khác số khách của Booking: hiện cảnh báo ở Tổng quan và trên tab. Các dịch vụ đã gửi theo số lượng cũ chuyển Cần điều chỉnh (R07).

### 3.5. DH08.5 · Nhân sự phục vụ Tour (TN07.03 · SYS07.03)

**L5.1 Xem lịch phân công.** **W50 · Chế độ Theo lịch hoặc Danh sách.** Lịch theo ngày Tour, mỗi nhân sự một dòng, ghi vai trò và ngôn ngữ; thanh phân công có màu theo vai trò. Ngôn ngữ phục vụ của đoàn xem ở header. Phân công lệch ngôn ngữ có dấu ⚠ và dòng lý do đã ghi. Bấm thanh phân công để sửa.

![W50 · Lịch nhân sự phục vụ](wireframes/W50.png)

**L5.2 Phân công.**

1. **W51 · Nút + Phân công → bảng trượt.** Chọn vai trò và phạm vi (Toàn Tour hoặc Theo ngày, có thể thêm giờ).
2. **W51 · Trường Nhân sự.** Danh sách lấy từ DH06 và sắp theo thứ tự: khớp ngôn ngữ và còn trống lịch, khớp ngôn ngữ nhưng bận, rồi đến các trường hợp còn lại. Nhân sự bận hiện mã Tour đang trùng.
3. **W51 → W50 · Nút Lưu phân công.** Chọn nhân sự, nhập lý do nếu lệch ngôn ngữ, rồi lưu. Lịch nhân sự hiện thanh phân công mới.

   ![W51 · Phân công HDV khác ngôn ngữ](wireframes/W51.png)

**Ngoại lệ (quyết định Q3)**

- **E5.1 · W51.** Vai trò HDV mà nhân sự không có ngôn ngữ phục vụ của đoàn: cảnh báo và bắt buộc nhập lý do mới cho lưu.
- **E5.2 · W52.** Trùng lịch với phân công khác (cùng hoặc khác Tour): banner đỏ trong bảng trượt, chặn lưu (R12), hiện Tour, vai trò và khoảng trùng. Nút Đổi sang Theo ngày… tự điền các ngày còn trống của nhân sự. Muốn chọn người khác thì chọn lại ngay ở trường Nhân sự.

  ![W52 · Chặn phân công trùng lịch](wireframes/W52.png)

### 3.6. DH08.6 · Nhật ký và sự cố (TN08.02, TN08.03 · SYS08.04, SYS08.05)

**L6.1 Ghi nhật ký.** **W55 · Ô nhập ở đầu tab.** Thời điểm điền sẵn là hiện tại. Gõ nội dung rồi bấm Enter hoặc Lưu nhật ký. Bản ghi hiện ngay ở đầu dòng thời gian và ô nhập được xóa. Chip lọc Tất cả, Nhật ký, Sự cố đang mở và ô chọn ngày lọc ngay.

![W55 · Nhật ký và sự cố](wireframes/W55.png)

**L6.2 Ghi sự cố.** **W56 · Nút + Sự cố → bảng trượt.** Ngày Tour tự suy ra từ thời điểm. Nhập nội dung và cách xử lý; kết quả có thể để trống. Nếu có chi phí, chọn Có chi phí phát sinh và nhập số tiền, loại tiền, chứng từ. Bấm Lưu sự cố: hệ thống tạo sự cố và dòng chi phí liên kết ở DH08.7 trong một giao dịch.

![W56 · Ghi sự cố](wireframes/W56.png)

**L6.3 Cập nhật kết quả.** **W57 · Nút Cập nhật kết quả trên sự cố Đang xử lý → bảng trượt.** Nhập kết quả rồi bấm Lưu kết quả. Sự cố chuyển Đã xử lý; số trên tab giảm.

![W57 · Cập nhật kết quả sự cố](wireframes/W57.png)

**Ngoại lệ**

- **E6.1.** Thiếu nội dung hoặc lưu lỗi: hiện lỗi, giữ chữ đã gõ.

### 3.7. DH08.7 · Chi phí phát sinh (TN08.04, lối vào TN08.05 · SYS08.06, SYS08.09)

**L7.1 Điều hành thêm khoản.**

1. **W60 · Bảng chi phí phát sinh.** Chip Chưa ghi công nợ; dòng tổng theo loại tiền. Khoản chưa ghi công nợ có nút Sửa; khoản đã ghi hiện “Sửa tại KT01” thay cho nút Sửa.

   ![W60 · Danh sách chi phí phát sinh](wireframes/W60.png)

2. **W61 · Nút + Chi phí phát sinh → bảng trượt.** Nhập ngày, nội dung, số tiền, loại tiền, NCC (nếu có), gợi ý thu lại từ khách và tải chứng từ (R13), rồi bấm Lưu chi phí. Khoản mới hiện Chưa ghi công nợ.

   ![W61 · Thêm chi phí phát sinh](wireframes/W61.png)

**L7.2 Kế toán ghi công nợ.** **W63 · Ô chọn đầu dòng (một hoặc nhiều khoản) → thanh hàng loạt.** Kế toán chọn các khoản Chưa ghi công nợ rồi bấm Ghi công nợ (n) tại KT01.3. KT01.3 mở với Tour Code và các khoản điền sẵn. Khi khoản công nợ liên kết được lưu ở KT01, DH08.7 hiện Đã ghi công nợ. Nếu thoát KT01.3 mà chưa lưu, chỉ báo giữ nguyên.

![W63 · Kế toán ghi công nợ](wireframes/W63.png)

**Ngoại lệ**

- **E7.1 · W62.** Tệp sai định dạng, vượt 10 MB hoặc tải lỗi: báo lỗi theo từng tệp trong danh sách tệp của bảng trượt, có nút Tải lại hoặc Bỏ. Nút Lưu khóa cho đến khi xử lý xong tệp lỗi; các trường khác được giữ (R13).

  ![W62 · Lỗi tải chứng từ](wireframes/W62.png)

- **E7.2.** Khoản đã ghi công nợ: DH08 không cho sửa số tiền, loại tiền hoặc xóa, chỉ cho bổ sung chứng từ và ghi chú. Thay đổi giá trị thực hiện ở KT01.
- **E7.3.** Khoản vừa được ghi ở phiên khác: tải lại liên kết, mở khoản đã ghi và không tạo trùng.

### 3.8. DH08.8 · Quyết toán và đóng Tour (TN09.01–TN09.04 · SYS09.01–SYS09.07)

Tab hiện 3 bước: (1) Chi phí thực tế · Điều hành, (2) Đối chiếu và P&L · Kế toán, (3) Đóng Tour · Điều hành.

**L8.1 Điều hành nhập chi phí thực tế.**

1. **W71 · Bước 1; form tại tab.** Mỗi dịch vụ đã xác nhận có một dòng. Ô Chi phí thực tế điền sẵn giá NCC xác nhận, gắn nhãn Gợi ý; chênh lệch tự tính. Điều hành sửa ô có số khác, nhập lý do khi chênh lệch khác 0 và đính kèm chứng từ. Bấm Lưu (lưu nhiều lần được), hoặc Lưu và chuyển Kế toán.

   ![W71 · Bước 1 · Nhập chi phí thực tế](wireframes/W71.png)

2. **W71a · Banner xanh; bước 1 có dấu ✓.** Bước 1 được đánh dấu xong, hiện tóm tắt chi phí, chênh lệch và chứng từ; Kế toán nhận thông báo nội bộ. Điều hành vẫn bấm Sửa chi phí được cho tới khi Kế toán lưu quyết toán.

   ![W71a · Đã chuyển Kế toán](wireframes/W71a.png)

**L8.2 Kế toán đối chiếu và lưu quyết toán.**

1. **W72 · Bước 2; form tại tab.** Hệ thống điền sẵn doanh thu từ Booking và khoản phải thu liên kết ở KT01, chi phí từ bước 1 và DH08.7, kèm bảng đối chiếu AP theo NCC giữa số KT01 và chi phí thực tế (hiện chênh lệch). Ngoại tệ quy đổi theo R15. Kế toán nhập kết quả đối chiếu AR và AP, thêm điều chỉnh có lý do, nhập tỷ giá còn thiếu, rồi bấm Lưu quyết toán.

   ![W72 · Bước 2 · Đối chiếu và tính lãi lỗ](wireframes/W72.png)

2. **W73 · Banner xanh; nút Đóng Tour ở header.** Hệ thống tính P&L theo R15, lưu phiên bản quyết toán (R16) và hiện dấu mốc Đã quyết toán, kèm tóm tắt P&L và công nợ hiện tại ngay trên tab.

   ![W73 · Quyết toán đã lưu](wireframes/W73.png)

**L8.3 Đóng Tour.**

1. **W74 · Nút Đóng Tour ở header → hộp thoại.** Hộp thoại nhắc công nợ còn lại sẽ tiếp tục ghi ở KT01. Điều hành bấm Đóng Tour. Hệ thống kiểm tra R16, khóa hồ sơ, cập nhật KD04.2; header hiện Đã đóng.

   ![W74 · Xác nhận đóng Tour](wireframes/W74.png)

2. **W75 · Banner khóa; mọi tab chỉ đọc.** Nút Xem công nợ Tour mở KT01.3 lọc theo Tour Code. Nút Mở lại Tour chỉ hiện với người phụ trách hồ sơ. Khách được đưa vào KD04.2.

   ![W75 · Tour đã đóng](wireframes/W75.png)

**L8.4 Mở lại Tour (quyết định Q2B).**

1. **W76 · Nút Mở lại Tour → hộp thoại.** Điều hành phụ trách hồ sơ nhập lý do rồi bấm Mở lại Tour. Hồ sơ trở về Đã kết thúc với chỉ báo Đã mở lại; mọi phiên bản quyết toán cũ chuyển “Trước mở lại”.

   ![W76 · Mở lại Tour](wireframes/W76.png)

2. **W77 · Header (nút Đóng Tour khóa, có ghi chú); banner vàng; bảng phiên bản.** Phải lưu phiên bản quyết toán mới thì Đóng Tour mới mở. Bấm dòng Phiên bản 1 trong bảng để xem bản cũ.

   ![W77 · Chưa đóng lại được](wireframes/W77.png)

**Ngoại lệ**

- **E8.1 · W70.** Mở tab khi hồ sơ chưa Đã kết thúc: vùng nội dung hiện lý do, trạng thái hiện tại, điều kiện mở tab và nút Về Tổng quan.

  ![W70 · Quyết toán chưa mở](wireframes/W70.png)

- **E8.2 · W77.** Chưa có quyết toán hiện hành: nút Đóng Tour khóa và có ghi chú “Cần lưu quyết toán mới”.
- **E8.3.** Thiếu tỷ giá cho khoản ngoại tệ chưa liên kết KT01: lỗi cạnh dòng; Lưu quyết toán khóa đến khi Kế toán nhập tỷ giá.
- **E8.4.** Dữ liệu nguồn thay đổi trong lúc Kế toán đang soạn (Điều hành sửa chi phí, KT01 có giao dịch mới): khi bấm Lưu, hiện danh sách số đã thay đổi và nút Tải lại số liệu; không ghi đè ngầm.
- **E8.5.** Đóng lỗi hoặc hồ sơ vừa đổi ở phiên khác: giữ trạng thái cũ, báo lý do và tải lại.
- **E8.6.** Còn lần đặt Chờ kết quả hoặc Yêu cầu hủy đang chờ: hộp thoại đóng Tour hiện cảnh báo, không chặn.
- **E8.7.** Công nợ còn dư: không chặn đóng (theo nguồn SYS09).

---

## 4. Quy tắc triển khai chi tiết

### R01. Khối Việc cần làm trước khởi hành

| Mục | Đạt khi | Mô tả khi chưa đạt | Nút |
|---|---|---|---|
| Đặt dịch vụ | Mọi hạng mục không ở trạng thái Đã hủy đều Đã xác nhận | “n cần đặt, m cần đặt lại” (thêm “k chờ kết quả”, “j chờ Kinh doanh” nếu có) | Đặt dịch vụ (mở DH08.3, lọc Cần đặt) |
| Checklist | Mọi công việc đang áp dụng đều Hoàn tất | “còn n việc chưa xong, k quá hạn” | Xem việc (mở DH08.2, lọc Chưa xong) |
| Giấy tờ khách | Đủ số khách của Booking, đủ trường bắt buộc và 0 cảnh báo giấy tờ | “n khách cần kiểm tra” hoặc “thiếu n khách” | Xem khách (mở DH08.4, lọc Cần kiểm tra giấy tờ) |
| Phân phòng | Mọi khách được xếp phòng ở mọi đợt lưu trú | “n khách chưa xếp phòng” | Xếp phòng (mở đợt đầu tiên còn thiếu) |
| HDV | Có phân công HDV chính phủ toàn Tour và khớp ngôn ngữ | “Chưa có HDV tiếng …” | Phân công (mở W51) |

- Mục chưa đạt xếp theo thứ tự trong bảng. Mục đã đạt không có dòng riêng; tên mục được ghép vào dòng “✓ Đã xong”.
- Khi mọi mục đều đạt, khối chỉ hiện “✓ Sẵn sàng khởi hành” và nút Bắt đầu Tour.
- Khối này chỉ để thông tin. Hộp thoại Bắt đầu Tour liệt kê các mục chưa đạt nhưng không chặn.

### R02. Trạng thái hạng mục dịch vụ

Hệ thống tính trạng thái theo thứ tự ưu tiên sau, sau mỗi lần ghi lần đặt:

1. Hạng mục bị bỏ, bị hủy theo Booking khi chưa từng gửi NCC, hoặc mọi lần đặt từng xác nhận đều đã Đã hủy: **Đã hủy**.
2. Có lần đặt còn hiệu lực (Đã gửi hoặc Đã xác nhận) phải hủy theo thay đổi chương trình mà chưa gửi yêu cầu hủy: **Cần hủy**.
3. Có lần đặt còn hiệu lực mà dữ liệu đã đổi sau khi gửi (thay đổi chương trình hoặc R07) và chưa gửi điều chỉnh: **Cần điều chỉnh**.
4. Tổng số xác nhận còn hiệu lực (lần đặt Đã xác nhận, chưa Đã hủy) bằng số lượng yêu cầu: **Đã xác nhận**.
5. Tổng số xác nhận lớn hơn 0 nhưng nhỏ hơn số yêu cầu: **Xác nhận một phần** (nếu đang có lần đặt Đã gửi thì thêm chỉ báo “đang chờ n”).
6. Có lần đặt Đã gửi chưa có kết quả: **Chờ kết quả**.
7. Có yêu cầu đổi lịch trình ở trạng thái Chờ Kinh doanh: **Chờ Kinh doanh**.
8. Lần đặt gần nhất có kết quả Không đáp ứng: **Cần đặt lại**.
9. Chưa có lần đặt: **Cần đặt**.

Sau khi gửi yêu cầu hủy hoặc email điều chỉnh, hạng mục rời Cần hủy / Cần điều chỉnh và trở về nhãn tính từ lần đặt (thường là Đã xác nhận), kèm chỉ báo Yêu cầu hủy đang chờ hoặc Điều chỉnh đang chờ. Chỉ báo này không thay đổi nhãn chính. Hạng mục Xác nhận một phần có yêu cầu đổi lịch trình đang mở giữ nhãn Xác nhận một phần và thêm chỉ báo Chờ Kinh doanh. Đặt phần còn thiếu chỉ cho đặt tối đa bằng số yêu cầu trừ tổng số đã xác nhận và tổng số đang chờ.

### R03. Checklist tự hoàn tất theo sự kiện

- Mỗi công việc mẫu ở DH01 có thuộc tính “Tự hoàn tất khi” (RSD DH01 R04) với các giá trị: không có; hạng mục liên kết Đã xác nhận (chỉ việc theo dịch vụ); đã gửi Rooming list cho mọi khách sạn; đã gửi Pax list; có HDV chính khớp ngôn ngữ.
- Khi sự kiện xảy ra, công việc tự chuyển Hoàn tất và lịch sử ghi “Hệ thống”. Khi sự kiện bị đảo ngược (hạng mục chuyển Cần đặt lại hoặc phân công HDV bị bỏ), công việc trở về Đang làm.
- Người dùng vẫn được đổi tiến độ bằng tay. Đổi tay ghi đè trạng thái tự động cho đến lần sự kiện tiếp theo.
- Công việc gắn với dịch vụ bị bỏ được loại khỏi mẫu số và vẫn giữ trong lịch sử.

### R04. Gộp email và chỉ báo chờ phản hồi

- Khi gửi hàng loạt, hệ thống gộp email theo cặp (NCC, mẫu email). Mỗi email có thể gồm nhiều hạng mục, nhưng mỗi hạng mục vẫn có lần đặt riêng và tham chiếu cùng mã gửi.
- Chỉ dòng Cần đặt có NCC và email hợp lệ được chọn để gửi hàng loạt. Dòng thiếu dữ liệu hiện trong bảng trượt với nhãn Cần bổ sung và không được gửi cho đến khi bổ sung xong.
- “Chọn tất cả” chỉ chọn các dòng trong trang đang xem và phù hợp bộ lọc.
- Chỉ báo “n ngày chưa phản hồi” hiện khi lần đặt Đã gửi quá 48 giờ. Ngưỡng này cấu hình được ở Quản trị.

### R05. Nút chính trên dòng DH08.3

| Trạng thái | Nút chính | Menu ⋯ |
|---|---|---|
| Cần đặt | Đặt dịch vụ | Đổi NCC, Bỏ dịch vụ (ở DH08.2) |
| Chờ kết quả | Ghi kết quả | Xem email, Hủy lần đặt |
| Xác nhận một phần | Đặt phần còn thiếu | Ghi kết quả lần đang chờ, Hủy |
| Cần đặt lại | Đặt lại | Xem lịch sử |
| Chờ Kinh doanh | Xem yêu cầu | Xem lịch sử |
| Cần điều chỉnh | Gửi điều chỉnh (W35, email soạn sẵn) | Không cần gửi, Xem lịch sử |
| Cần hủy | Gửi yêu cầu hủy (W39a, email soạn sẵn) | Xem lịch sử |
| Đã xác nhận | Không có | Hủy lần đặt, Xem lịch sử |
| Đã hủy | Không có | Xem lịch sử |
| Có Yêu cầu hủy đang chờ | Ghi kết quả hủy | Xem email hủy |

### R06. Tổng hợp yêu cầu riêng vào email

- Mỗi nhãn yêu cầu riêng thuộc một nhóm áp dụng: **Ăn uống** (ăn chay, không gluten, dị ứng: …, khác) áp dụng cho loại dịch vụ Nhà hàng và Du thuyền; **Phòng** (tầng thấp, giường phụ, phòng đơn, khác) áp dụng cho Khách sạn và Du thuyền. Danh mục nhãn và nhóm áp dụng do Quản trị cấu hình.
- Câu tổng hợp đếm số khách theo nhãn, ví dụ “2 suất chay; 1 khách dị ứng hải sản có vỏ (tôm, cua)”. Tên khách không đưa vào email, trừ khi mẫu có trường tên.
- Mẫu email QT04.2 có trường tự điền `{yeu_cau_rieng}`. Khi mẫu không có trường này, hệ thống chèn câu tổng hợp vào trước lời kết.
- Bản chụp câu đã gửi được lưu theo lần đặt.

### R07. Phát hiện thay đổi sau lần đặt

- Khi lưu khách hoặc phân phòng, hệ thống so dữ liệu hiện tại với bản chụp của lần đặt còn hiệu lực gần nhất (Đã gửi hoặc Đã xác nhận) của từng hạng mục liên quan:
  - Yêu cầu ăn uống: hạng mục Nhà hàng và Du thuyền.
  - Yêu cầu phòng và số khách: hạng mục Khách sạn và Du thuyền.
  - Chuyến bay: hạng mục có loại Đón sân bay hoặc Tiễn sân bay cùng ngày bay.
- Khi có khác biệt, hạng mục chuyển **Cần điều chỉnh** kèm loại thay đổi, và email điều chỉnh được soạn sẵn. Gửi điều chỉnh hoặc Không cần gửi (có lý do) sẽ lưu bản chụp mới và đưa hạng mục về nhãn trước đó.
- Hạng mục chưa gửi không có chỉ báo, vì email soạn sau luôn dùng dữ liệu mới nhất.

### R08. Chống gửi trùng và lỗi chưa xác định

- Mỗi lần bấm Gửi sinh một mã gửi. Bấm lặp hoặc thử lại tự động dùng cùng mã đó. Lần đặt chỉ được tạo khi dịch vụ thư xác nhận đã nhận email.
- Khi gửi trả lỗi rõ ràng: không tạo lần đặt, giữ email và cho Gửi lại.
- Khi không rõ kết quả (hết thời gian chờ, mất kết nối): trạng thái Đang kiểm tra; hệ thống tra theo mã gửi mỗi 30 giây, tối đa 5 phút. Nếu đã gửi, tạo lần đặt. Nếu chưa gửi, mở Gửi lại. Nếu vẫn chưa rõ, cho Gửi lại kèm cảnh báo có thể trùng; lần gửi mới dùng mã mới và ghi liên kết tới mã cũ.

### R09. Thao tác hàng loạt

| Nơi | Thao tác | Dòng được chọn | Kết quả |
|---|---|---|---|
| DH08.2 | Giao cho, đổi tiến độ | Công việc chưa bị bỏ (dòng dịch vụ không chọn được) | Kết quả theo từng dòng; dòng lỗi giữ chọn để thử lại |
| DH08.3 | Soạn email đặt | Cần đặt có NCC | Theo từng NCC (W23) |
| DH08.3 | Gửi email hủy theo Booking đã hủy | Lần đặt Đã gửi hoặc Đã xác nhận | Theo từng NCC; Cần đặt chuyển Đã hủy |
| DH08.4 | Nhập Excel | Mọi dòng trong tệp | Cập nhật, mới, lỗi |
| DH08.4 | Gán chuyến bay, Thêm yêu cầu riêng | Khách đang chọn | Cập nhật mọi khách đã chọn trong một giao dịch |
| DH08.4 | Gửi Pax list | NCC đã chọn | Theo từng NCC |
| DH08.7 | Ghi công nợ | Khoản Chưa ghi công nợ | Mở KT01.3 với danh sách khoản |
| DH08.8 | Điền gợi ý | Ô chi phí thực tế còn trống | Điền giá NCC xác nhận |

Một dòng đổi trạng thái ở phiên khác sau khi đã được chọn sẽ bị loại khỏi lần áp dụng và được báo trong kết quả.

### R10. Sửa kết quả đặt và liên kết công nợ

- Kết quả chưa ghi phải trả ở KT01: Điều hành sửa trên đúng lần đặt, phải nhập lý do, và lịch sử lưu giá trị trước và sau. Sau khi sửa, dòng ở KT01.2 · Chờ ghi phải trả cập nhật theo.
- Kết quả đã liên kết khoản phải trả: DH08 chỉ cho sửa ghi chú và mã. Số lượng, giá và phí được điều chỉnh ở KT01 theo quyền và liên kết về lần đặt.
- Một lần đặt chỉ liên kết với một khoản phải trả cho mỗi loại (dịch vụ, phí hủy).

### R11. Kiểm tra giấy tờ khách

- **Cảnh báo hộ chiếu** khi ngày hết hạn sớm hơn ngày bắt đầu Tour cộng N tháng. N mặc định là 6 và cấu hình được.
- **Cảnh báo visa** khi tình trạng visa là “Cần visa · chưa có”, hoặc khi hạn visa sớm hơn ngày kết thúc Tour. Các giá trị tình trạng visa: Không cần visa, Cần visa · chưa có, Đã có visa, Visa tại cửa khẩu. Người dùng chọn giá trị; hệ thống không tự suy ra quy định miễn thị thực.
- Cảnh báo không chặn lưu, xuất hoặc gửi. Số cảnh báo được tính vào số trên tab và mục Giấy tờ khách của Tổng quan.
- Số hộ chiếu được chuẩn hóa (bỏ khoảng trắng, chữ hoa) để kiểm tra trùng trong cùng Tour.

### R12. Phân công nhân sự

- Phạm vi Toàn Tour dùng khoảng từ thời điểm bắt đầu dự kiến đến thời điểm kết thúc dự kiến (lấy giờ chuyến bay đến và về nếu có, nếu không thì 00:00 ngày đầu đến 23:59 ngày cuối). Phạm vi Theo ngày dùng cả ngày, hoặc khoảng giờ đã nhập.
- Hai phân công của cùng một nhân sự bị coi là trùng khi bắt đầu của khoảng này trước kết thúc của khoảng kia và ngược lại. Hai khoảng chỉ chạm nhau ở mốc đầu hoặc cuối không bị coi là trùng. Kiểm tra áp dụng cho mọi Tour chưa đóng và chạy lại khi bấm Lưu.
- Danh mục nhân sự DH06 cần thêm trường Ngôn ngữ (chọn nhiều). Kiểm tra lệch ngôn ngữ chỉ áp dụng cho vai trò HDV.

### R13. Chứng từ

- Nhận tệp PDF, JPG, PNG, tối đa 10 MB mỗi tệp và 10 tệp mỗi bản ghi. Mỗi tệp hiện tên, dung lượng, tiến độ tải và lỗi riêng.
- Khi còn tệp đang tải hoặc tải lỗi, nút Lưu khóa.

### R14. Booking đã hủy (quyết định Q1B)

- Khi KD08 ghi Booking Đã hủy, hệ thống làm các việc sau:
  - Gắn chỉ báo Booking đã hủy lên hồ sơ.
  - Khóa Bắt đầu Tour, Đặt dịch vụ, Đặt lại, Đặt phần còn thiếu và Soạn email đặt.
  - Gửi thông báo nội bộ cho Điều hành phụ trách.
  - Soạn sẵn bản nháp email hủy theo từng NCC cho mọi lần đặt Đã gửi hoặc Đã xác nhận.
- Hệ thống không tự gửi email. Điều hành kiểm tra rồi bấm gửi (W32).
- Hạng mục Cần đặt hoặc Cần đặt lại chuyển Đã hủy, lý do “Booking đã hủy”.
- Nút **Kết thúc hồ sơ** mở khi mọi lần đặt còn hiệu lực đã gửi yêu cầu hủy thành công. Hồ sơ chuyển Đã kết thúc, lý do kết thúc “Booking đã hủy”, để Kế toán quyết toán phí hủy và khoản cần hoàn.
- Nếu Booking bị hủy khi Tour đang diễn ra: hiện chỉ báo và chặn đặt mới; luồng Kết thúc Tour giữ nguyên.

### R15. Quyết toán, tỷ giá và P&L

- **Đồng tiền quyết toán.** Toàn bộ quyết toán tính bằng VND.
- **Tỷ giá.** Khoản đã liên kết KT01 dùng tỷ giá đã ghi ở KT01. Khoản chưa liên kết dùng tỷ giá theo ngày phát sinh, điền sẵn từ bảng tỷ giá của Kế toán; nếu chưa có, Kế toán nhập tay. Tỷ giá dùng cho từng khoản được lưu trong phiên bản quyết toán.
- **Doanh thu thực tế.** Giá trị Booking đã chốt, cộng các khoản phải thu phát sinh liên kết Tour ở KT01.
- **Chi phí thực tế.** Chi phí thực tế từng dịch vụ ở bước 1, cộng chi phí phát sinh. Một khoản đã liên kết KT01 chỉ được tính một lần, theo số KT01; dòng nhập ở DH08 chỉ giữ vai trò tham chiếu.
- **P&L.** P&L thực tế = doanh thu thực tế − chi phí thực tế + điều chỉnh ròng (điều chỉnh có dấu). Biên = P&L ÷ doanh thu thực tế. P&L dự tính lấy từ phiên bản báo giá đã chốt và chỉ dùng để so sánh.
- **Cảnh báo trùng.** Hai dòng cùng NCC, ngày, số tiền và loại tiền được cảnh báo trùng; Kế toán xác nhận hoặc liên kết lại trước khi lưu.

### R16. Phiên bản quyết toán, đóng và mở lại (quyết định Q2B)

- **Lưu nhiều lần.** Trước khi đóng, mỗi lần Kế toán bấm Lưu quyết toán sẽ tạo một phiên bản mới, trở thành bản Hiện hành. Các bản trước được giữ để xem.
- **Điều kiện đóng.** Đóng Tour cần một phiên bản Hiện hành được lưu sau lần mở lại gần nhất (nếu có).
- **Khi đóng.** Hệ thống khóa ghi mọi tab, ghi thời điểm và người đóng. Hệ thống tạo hoặc cập nhật đúng một mục lịch sử khách ở KD04.2 theo Tour Code.
- **Khi mở lại.** Chỉ Điều hành phụ trách hồ sơ được mở lại và phải nhập lý do. Mọi phiên bản cũ chuyển “Trước mở lại”; mục ở KD04.2 hiện Đang cập nhật. Đóng lại sẽ cập nhật cùng mục đó, không tạo mục mới.
- **Lịch sử.** Lịch sử mở lại, đóng lại và lý do hiển thị trong tab Quyết toán.

### R17. Cấu hình phụ thuộc

| Cấu hình | Chủ sở hữu | Dùng ở | Khi thiếu |
|---|---|---|---|
| Hộp thư chung gửi NCC | Quản trị | Mọi email | Nút Gửi khóa và báo “Chưa cấu hình hộp thư gửi” |
| Mẫu email theo loại dịch vụ và ngôn ngữ (QT04.2) | Điều hành | DH08.3 | E3.1, có nút Soạn không theo mẫu |
| Mẫu Pax list, Rooming list và tập cột theo loại NCC | Điều hành | DH08.4 | Dùng tập cột mặc định: họ tên, giới tính, quốc tịch |
| Sức chứa theo hạng phòng | Điều hành | Phân phòng | Chặn lưu và yêu cầu cấu hình |
| Danh mục nhãn yêu cầu riêng | Quản trị | DH08.4, R06 | Chỉ có ô ghi chú tự do; không tổng hợp |
| Ngưỡng hộ chiếu (tháng), ngưỡng chờ phản hồi (giờ) | Quản trị | R11, R04 | Mặc định 6 tháng, 48 giờ |
| Hạn phản hồi của Kinh doanh (ngày làm việc) | Quản trị | R18 | Mặc định 2 ngày làm việc |
| Ngôn ngữ của nhân sự (DH06) | Điều hành | DH08.5 | Không gợi ý và không cảnh báo lệch ngôn ngữ |

### R18. Yêu cầu đổi lịch trình gửi Kinh doanh

- **Mở yêu cầu.** Từ bảng trượt Đặt lại (W28), với hạng mục Cần đặt lại hoặc Xác nhận một phần. Mỗi hạng mục chỉ có một yêu cầu ở trạng thái Chờ Kinh doanh.
- **Gửi.** Người nhận mặc định là Kinh doanh phụ trách Booking. Hệ thống gửi thông báo trong hệ thống và email nội bộ có liên kết mở DH08.3 kèm bảng trượt của yêu cầu. Hạn phản hồi mặc định là 2 ngày làm việc (cấu hình được) và phải trước ngày sử dụng ít nhất 1 ngày.
- **Khi chờ.** Hạng mục ở trạng thái Chờ Kinh doanh không cho gửi đặt, đặt lại hay đặt phần thiếu. Vẫn cho Điều hành ghi kết quả của lần đặt đang chờ và rút yêu cầu.
- **Kinh doanh xử lý** ở màn Kinh doanh, sau khi thống nhất với khách hoặc đại lý, rồi gửi Điều hành (L3.12 bước 3–4). Yêu cầu đóng theo L1.5 và R19, hoặc khi Điều hành rút (E3.14).
- **Giá bán.** DH08 không đổi giá bán đã chốt. Chênh lệch giá bán với khách, nếu có, do Kinh doanh xử lý ở Booking (KD08). Chênh lệch chi phí thể hiện ở Quyết toán.
- **Lịch sử.** Mọi bước được lưu người, thời điểm và nội dung, xem trong lịch sử của hạng mục (W29).

### R19. Thay đổi chương trình từ Kinh doanh

- **Nguồn.** Mỗi lần Kinh doanh bấm Gửi Điều hành ở KD08 tạo một phiên bản chương trình mới cho Tour Code. Phiên bản mới gửi trước khi áp dụng thay thế phiên bản đang chờ (E1.6).
- **Trước khi áp dụng.** Dữ liệu hồ sơ không đổi. Hạng mục bị thay đổi chạm tới có chỉ báo Chờ áp dụng thay đổi. Nút Đặt dịch vụ, Đặt lại và Gửi điều chỉnh trên các hạng mục này bị khóa, kèm chú thích, để tránh đặt theo dữ liệu cũ. Hạng mục khác thao tác bình thường.
- **So sánh.** Chỉ những mục khác nhau giữa bản cũ và bản mới mới hiện trong W09.
- **Áp dụng.** Một lần cho cả phiên bản, không áp dụng từng dòng. Áp dụng chạy trong một giao dịch: thành công hết hoặc không đổi gì; bấm lặp hoặc hai người cùng áp dụng chỉ tạo một lần áp dụng. Hệ thống cập nhật các mục thay đổi trong hồ sơ như sau:

| Thay đổi | Hạng mục chưa gửi NCC (Cần đặt, Cần đặt lại, Chờ Kinh doanh) | Hạng mục đã gửi hoặc đã xác nhận |
|---|---|---|
| Thêm dịch vụ | Tạo hạng mục Cần đặt và các việc theo dịch vụ của mẫu hồ sơ đã dùng, phiên bản hiện hành (RSD DH01 R07) | — |
| Bỏ dịch vụ | Chuyển Đã hủy, bỏ công việc chỉ gắn với hạng mục | **Cần hủy**; email hủy soạn sẵn (W39a). Gửi xong và NCC xác nhận hủy thì Đã hủy |
| Đổi dịch vụ / NCC | Cập nhật dịch vụ, NCC, giá tham chiếu; trạng thái Cần đặt | **Cần hủy** lần đặt cũ; email hủy soạn sẵn. Sau khi NCC xác nhận hủy, hạng mục chuyển Cần đặt với dịch vụ mới |
| Đổi ngày, số lượng, yêu cầu | Cập nhật trực tiếp | **Cần điều chỉnh**; email điều chỉnh soạn sẵn với bảng bản cũ và bản mới (W35). Gửi xong thì về Đã xác nhận kèm chỉ báo Điều chỉnh đang chờ; NCC không đáp ứng điều chỉnh thì ghi Không đáp ứng và chuyển Cần đặt lại |

- **Phần còn lại của hồ sơ.**
  - Lịch trình Tổng quan cập nhật theo phiên bản mới.
  - Hạn công việc checklist chưa Hoàn tất được tính lại theo mốc của mẫu (RSD DH01 R03); hạn đã sửa tay thì giữ nguyên.
  - Đợt lưu trú theo khách sạn mới giữ nguyên cách xếp phòng.
  - Phân công nhân sự theo ngày bị đổi được kiểm tra lại trùng lịch (R12). Nếu trùng, phân công vẫn giữ nhưng có cảnh báo ở tab Nhân sự.
- **Email soạn sẵn, không tự gửi.** Điều hành mở từng dịch vụ, kiểm tra rồi bấm Gửi (L1.5 bước 3–5).
- **Sau khi áp dụng.** Chỉ báo Theo thay đổi vN giữ cho tới khi hạng mục Đã xác nhận hoặc Đã hủy. Kinh doanh nhận thông báo Đã áp dụng. Yêu cầu đổi lịch trình liên quan chuyển Đã xử lý.
- **Lịch sử.** Lưu người áp dụng, thời điểm, phiên bản cũ và mới, và danh sách thay đổi.

---

## 5. Dữ liệu

### 5.1. Đối tượng dữ liệu

| Đối tượng | Khóa và dữ liệu chính | Nguồn hoặc tác động |
|---|---|---|
| Hồ sơ Tour | Tour Code, ID Booking, trạng thái, thời điểm bắt đầu, thời điểm kết thúc, Điều hành phụ trách, ngôn ngữ phục vụ, ghi chú, lý do kết thúc, cờ Đã mở lại | DH07 tạo; ngôn ngữ mặc định lấy từ Booking |
| Hạng mục dịch vụ | ID hạng mục, Tour Code, ngày dùng từ–đến, ID dịch vụ DH05, NCC hiện tại, số lượng, đơn vị, giá tham chiếu, loại tiền, yêu cầu gửi NCC, trạng thái (tính), chỉ báo phụ | Bóc tách từ Booking (DH07) hoặc thêm tay |
| Lần đặt | ID lần đặt, ID hạng mục, NCC, loại (đặt, đặt phần thiếu, đặt lại), số lượng yêu cầu, số lượng xác nhận, giá xác nhận, loại tiền, mã xác nhận, kết quả, lý do, thời điểm gửi, mã gửi, bản email đã gửi; phần hủy gồm lý do, thời điểm gửi hủy, kết quả hủy, phí, loại tiền, mã hủy, tệp | Xác nhận và phí hủy chuyển sang KT01.2 |
| Bản chụp dữ liệu gửi | ID lần đặt, yêu cầu riêng, chuyến bay, số khách tại thời điểm gửi | Dùng để phát hiện dịch vụ Cần điều chỉnh (R07) |
| Yêu cầu đổi lịch trình | ID, ID hạng mục, trạng thái, người gửi, người nhận, hạn phản hồi, loại đề xuất, nội dung đề xuất, ID thay đổi chương trình đã xử lý, người và thời điểm từng bước | Điều hành gửi; đóng khi thay đổi chương trình được áp dụng (R18) |
| Thay đổi chương trình | ID, Tour Code, phiên bản cũ (đang áp dụng) và phiên bản mới, người gửi, thời điểm, ghi chú của Kinh doanh, danh sách thay đổi (ngày, loại, hạng mục, giá trị bản cũ và bản mới), trạng thái, người áp dụng, thời điểm áp dụng | Kinh doanh gửi từ KD08; DH08 áp dụng (R19) |
| Công việc checklist | ID, ID mẫu nguồn, số phiên bản mẫu, ID công việc mẫu, ID hạng mục liên kết (nếu có), nội dung, hướng dẫn thực hiện, hạn, người thực hiện, tiến độ, sự kiện tự hoàn tất | Sinh từ DH01 khi tạo hồ sơ (DH07) hoặc khi thêm hạng mục (RSD DH01 R07); Điều hành cập nhật |
| Khách đoàn | ID khách, họ, tên, giới tính, ngày sinh, quốc tịch, điện thoại, số hộ chiếu (chuẩn hóa), ngày hết hạn, tình trạng visa, số visa, hạn visa, chuyến bay đến và về, nhãn yêu cầu riêng, ghi chú, trưởng đoàn | Kinh doanh nhập; Pax list |
| Đợt lưu trú và phòng | ID đợt (theo hạng mục khách sạn hoặc du thuyền), số phòng, hạng phòng, sức chứa, danh sách khách | Điều hành xếp; Rooming list |
| Phân công nhân sự | ID, ID nhân sự DH06, vai trò, phạm vi, từ–đến, lý do lệch ngôn ngữ | DH06 (cần thêm trường Ngôn ngữ) |
| Nhật ký và sự cố | ID, loại, thời điểm, ngày Tour, nội dung, cách xử lý, kết quả, ID chi phí liên kết | — |
| Chi phí phát sinh | ID, ngày, nội dung, số tiền, loại tiền, NCC, gợi ý thu khách, tệp, ID sự cố, ID khoản công nợ | KT01.3 ghi công nợ |
| Quyết toán | ID phiên bản, Tour Code, trạng thái phiên bản, chi phí thực tế từng dịch vụ, nguồn và tỷ giá từng khoản, kết quả đối chiếu AR và AP, điều chỉnh và lý do, doanh thu, chi phí, P&L, người lưu, thời điểm lưu | KT01, DH08.3, DH08.7 |
| Email gửi ra ngoài | Mã gửi, loại (đặt, đặt lại, hủy, cập nhật, Pax list, Rooming list), mẫu, NCC, người nhận, CC, tiêu đề, nội dung, tệp, trạng thái gửi, người gửi, thời điểm | Hộp thư chung |

### 5.2. Trường nhập chính

| Form | Trường | Bắt buộc | Mặc định hoặc điền sẵn | Kiểm tra |
|---|---|---|---|---|
| Thông tin điều hành | Điều hành phụ trách | Có | Người hiện tại | Thuộc nhóm Điều hành, đang cho phép phân công |
| Thông tin điều hành | Ngôn ngữ phục vụ | Có | Từ Booking | Thuộc danh mục ngôn ngữ |
| Bắt đầu Tour | Thời điểm bắt đầu | Có | Hiện tại | Không ở tương lai |
| Kết thúc Tour | Thời điểm kết thúc | Có | Hiện tại | Không sớm hơn thời điểm bắt đầu; không ở tương lai |
| Thêm dịch vụ | Ngày, dịch vụ, số lượng | Có | Số lượng bằng số khách | Ngày trong thời gian Tour; số lượng > 0 |
| Email đặt | Người nhận, tiêu đề, nội dung | Có | Từ DH03 và mẫu QT04.2 | Email hợp lệ; tiêu đề có Tour Code |
| Ghi kết quả | Kết quả, số lượng xác nhận, giá, loại tiền | Có | Số yêu cầu; giá tham chiếu | 0 < số xác nhận ≤ số yêu cầu; giá ≥ 0 |
| Ghi kết quả | Lý do (khi Không đáp ứng) | Có | — | — |
| Hủy lần đặt | Lý do | Có | Từ Booking khi hủy theo Booking | — |
| Báo Kinh doanh | Người nhận, loại đề xuất, nội dung đề xuất, hạn phản hồi | Có | Kinh doanh phụ trách Booking; hạn sau 2 ngày làm việc | Hạn trước ngày sử dụng ít nhất 1 ngày |
| Kết quả hủy | Kết quả, phí hủy, loại tiền | Có | Phí gợi ý theo chính sách đổi hủy của hợp đồng (DH03.2); không có thì 0 | Phí ≥ 0 |
| Khách | Họ, tên, giới tính, ngày sinh, quốc tịch, số hộ chiếu, ngày hết hạn | Có | Chuyến bay chung của đoàn | Ngày sinh không sau hôm nay; hộ chiếu không trùng trong Tour |
| Phân công | Vai trò, phạm vi, nhân sự | Có | — | R12; lý do bắt buộc khi lệch ngôn ngữ |
| Sự cố | Thời điểm, nội dung, cách xử lý | Có | Hiện tại | — |
| Chi phí phát sinh | Ngày, nội dung, số tiền, loại tiền | Có | — | Số tiền > 0; tệp theo R13 |
| Quyết toán bước 1 | Chi phí thực tế mỗi dịch vụ | Có trước khi chuyển Kế toán | Giá NCC xác nhận | ≥ 0; lý do khi chênh lệch khác 0 |
| Quyết toán bước 2 | Kết quả đối chiếu AR, AP; tỷ giá của khoản chưa liên kết | Có | Từ KT01 | Điều chỉnh phải có lý do |
| Mở lại Tour | Lý do | Có | — | — |

### 5.3. Dữ liệu gửi ra ngoài

| Tài liệu | Người nhận | Nội dung | Lúc gửi thật | Lưu lại |
|---|---|---|---|---|
| Email đặt, đặt lại, đặt phần thiếu | Email đặt dịch vụ của NCC (DH03) | Tour Code, dịch vụ, ngày, số lượng, yêu cầu dịch vụ, câu yêu cầu riêng, giá tham chiếu nếu mẫu có | Khi bấm Gửi | Bản email, mã gửi, trạng thái |
| Email hủy | Cùng NCC | Mã xác nhận, dịch vụ, ngày, lý do | Khi bấm Gửi yêu cầu hủy | Như trên |
| Email điều chỉnh | Cùng NCC | Bảng bản cũ và bản mới (dữ liệu khách hoặc thay đổi chương trình) | Khi bấm Gửi điều chỉnh | Như trên và bản chụp mới |
| Pax list | NCC đã chọn | Tập cột theo loại NCC (W48) | Khi bấm Gửi | Tệp đã gửi, danh sách cột, người nhận |
| Rooming list | Khách sạn hoặc du thuyền của đợt | Phòng, hạng phòng, khách, yêu cầu phòng | Khi bấm Gửi | Như trên |

Tải Excel hoặc PDF không phải là gửi và không ghi lịch sử gửi. Tên tệp có dạng `TourCode_LoaiTaiLieu_NCC.xlsx`.

---

## 6. Tiêu chí nghiệm thu

| Mã | Điều kiện và thao tác | Kết quả mong đợi |
|---|---|---|
| AC01 | Mở DH08 từ DH07, KD08.1, KD04.2, KT01.3, QT09 | Đúng Tour Code, đúng tab đích, đúng quyền; KD04.2 mở chỉ đọc |
| AC02 | Kinh doanh mở hồ sơ của Booking người khác phụ trách | Hiện W07, không lộ dữ liệu |
| AC03 | Tổng quan với checklist 12/18, 3 dịch vụ Cần đặt, 2 khách cảnh báo | Khối Việc cần làm hiện đúng 3 mục chưa đạt với đúng số; mục đã đạt gộp vào dòng Đã xong; mỗi nút mở đúng tab và đúng bộ lọc |
| AC04 | Bắt đầu Tour khi còn mục chưa sẵn sàng | Hộp thoại liệt kê đủ mục; xác nhận thì chuyển Đang diễn ra và ghi thời điểm đã chọn |
| AC05 | Kết thúc Tour với thời điểm sớm hơn thời điểm bắt đầu | Báo lỗi, không đổi trạng thái |
| AC06 | Kết thúc Tour hợp lệ | Trạng thái Đã kết thúc; tab Quyết toán mở bước 1 |
| AC07 | Chọn Hoàn tất ở ô Tiến độ của công việc cuối cùng chưa xong | Tab hiện 18/18 màu xanh; mục Checklist chuyển vào dòng Đã xong của Tổng quan |
| AC08 | Chọn 3 công việc, Phân công cho người đã bị tắt quyền nhận phân công | Không dòng nào được áp dụng; báo lý do theo từng dòng |
| AC09 | Bỏ dịch vụ chưa có lần đặt; bỏ dịch vụ đã có lần đặt | Trường hợp 1 bỏ được, công việc liên quan cũng bị bỏ; trường hợp 2 hiện W15 |
| AC10 | Chọn 3 hạng mục Cần đặt của 2 NCC rồi gửi | Tạo đúng 2 email; mỗi hạng mục có lần đặt riêng; chuyển Chờ kết quả |
| AC11 | Gửi hàng loạt khi 1 NCC lỗi | NCC thành công chuyển Chờ kết quả; NCC lỗi không tạo lần đặt, giữ email; Gửi lại phần lỗi chỉ gửi NCC lỗi |
| AC12 | Khách có yêu cầu ăn chay; đặt nhà hàng | Email có câu yêu cầu đặc biệt đúng số lượng; email khách sạn không có câu ăn uống |
| AC13 | Hạng mục chưa có NCC: chọn NCC | Email tự soạn với người nhận của NCC đã chọn |
| AC14 | Ghi xác nhận 7/10 rồi đặt phần còn thiếu | Hạng mục Xác nhận một phần; email phần thiếu điền 3; đủ 10 thì Đã xác nhận |
| AC15 | Ghi Không đáp ứng rồi Đặt lại với NCC khác | Lần đặt mới trên cùng hạng mục; lịch sử còn lần cũ và lý do |
| AC16 | Ghi xác nhận có giá khác giá tham chiếu | KT01.2 có dòng Chờ ghi phải trả với giá xác nhận; giá bán của Booking không đổi |
| AC17 | Hủy lần đặt: NCC chấp nhận có phí; trường hợp khác NCC từ chối | Trường hợp 1: Đã hủy, phí vào KT01.2. Trường hợp 2: giữ Đã xác nhận, lịch sử có lý do từ chối |
| AC18 | Booking bị hủy khi có 6 lần đặt ở 5 NCC và 2 hạng mục Cần đặt | Banner hiện; Bắt đầu Tour và các nút đặt khóa; W32 có 5 email; 2 hạng mục Cần đặt chuyển Đã hủy không gửi email |
| AC19 | Gửi email nhưng mất kết nối sau khi gửi | Hiện W34; không tạo trùng lần đặt; tra mã gửi trả về đúng kết quả |
| AC20 | Đổi chuyến bay của 2 khách sau khi đã đặt xe đón | Dịch vụ đón chuyển Cần điều chỉnh; Gửi điều chỉnh hiện so sánh và email soạn sẵn; gửi xong trở về Đã xác nhận kèm chỉ báo Điều chỉnh đang chờ |
| AC21 | Nhập khách có hộ chiếu hết hạn 02/2027 cho Tour bắt đầu 18/11/2026 | Lưu được; cảnh báo ở dòng, form, Tổng quan và khi gửi Pax list |
| AC22 | Nhập Excel 18 dòng, có 1 thiếu hộ chiếu và 1 trùng | Xem trước đúng 14 cập nhật, 2 mới, 2 lỗi; chỉ nhập 16 dòng |
| AC23 | Xếp 2 khách vào phòng SGL | Chặn lưu, phòng bị đánh dấu, thay đổi được giữ |
| AC24 | Tạo Rooming list khi đợt còn khách chưa xếp | Hiện W49 với tên khách chưa xếp |
| AC25 | Gửi Pax list cho khách sạn và du thuyền | Mỗi NCC một email; tệp chỉ có cột theo loại NCC; lịch sử gửi ghi đủ |
| AC26 | Phân công HDV không có tiếng Đức cho đoàn tiếng Đức | Cảnh báo; chỉ lưu được khi có lý do |
| AC27 | Phân công nhân sự đang bận ở Tour khác trong cùng khoảng giờ; khoảng giờ chỉ chạm nhau ở điểm đầu hoặc cuối | Trường hợp trùng bị chặn (W52); trường hợp chạm mốc vẫn lưu được |
| AC28 | Ghi sự cố có chi phí phát sinh | Tạo sự cố và dòng chi phí liên kết trong một lần lưu |
| AC29 | Kế toán chọn 2 khoản và ghi công nợ, thoát KT01.3 trước khi lưu | Chỉ báo vẫn Chưa ghi công nợ; lưu ở KT01 thì đổi thành Đã ghi công nợ |
| AC30 | Tải tệp 48 MB dạng MP4 | Lỗi theo tệp; nút Lưu khóa đến khi bỏ tệp |
| AC31 | Quyết toán có khoản USD đã liên kết KT01 và khoản USD chưa liên kết thiếu tỷ giá | Khoản liên kết dùng tỷ giá KT01; khoản chưa liên kết chặn lưu đến khi nhập tỷ giá |
| AC32 | Tính P&L | P&L = doanh thu thực tế − chi phí thực tế + điều chỉnh ròng; khoản liên kết KT01 không bị cộng hai lần |
| AC33 | Đóng Tour trước và sau khi lưu quyết toán, khi công nợ còn dư | Trước: nút khóa. Sau: đóng được, hồ sơ chỉ đọc, KT01 vẫn ghi được thu chi |
| AC34 | Mở lại Tour bằng người không phụ trách và bằng người phụ trách | Người không phụ trách không thấy nút; người phụ trách mở được với lý do; phải lưu quyết toán mới mới đóng lại được |
| AC35 | Hai người cùng sửa một dòng | Người lưu sau nhận thông báo xung đột và lựa chọn tải lại |
| AC36 | Hạng mục Không đáp ứng, không có NCC tương đương; bấm Báo Kinh doanh | Yêu cầu điền sẵn đúng hạng mục, ngày, NCC đã thử, lý do và người nhận; hạng mục chuyển Chờ Kinh doanh; Kinh doanh nhận thông báo có liên kết mở đúng yêu cầu |
| AC37 | Bấm Báo Kinh doanh lần hai khi yêu cầu còn mở | Không tạo yêu cầu mới; mở yêu cầu hiện có |
| AC38 | Sau yêu cầu đổi lịch trình, Kinh doanh sửa lịch trình ở màn Kinh doanh và gửi Điều hành | Hồ sơ hiện banner Chương trình có thay đổi; trong DH08 không có màn cho Kinh doanh phản hồi |
| AC39 | Áp dụng thay đổi đổi dịch vụ của hạng mục Chờ Kinh doanh, rồi đặt | Trước khi áp dụng, hạng mục giữ nguyên. Sau Áp dụng: đổi dịch vụ, NCC, giá tham chiếu, chuyển Cần đặt; yêu cầu đổi lịch trình Đã xử lý. Sau Gửi: Chờ kết quả, lần đặt #3; lịch sử lần đặt cũ giữ nguyên; giá bán Booking không đổi |
| AC40 | Thay đổi chương trình không chạm tới hạng mục đang Chờ Kinh doanh | Yêu cầu giữ Chờ Kinh doanh; dòng có ghi chú phiên bản mới chưa xử lý |
| AC41 | Quá hạn phản hồi | Chỉ báo đỏ trên dòng và trên Tổng quan; Kinh doanh nhận một lần nhắc |
| AC42 | Kinh doanh chuyển thay đổi chương trình do đại lý yêu cầu (không có NCC không đáp ứng) | Hồ sơ hiện banner trên mọi tab; dữ liệu hồ sơ chưa đổi cho tới khi Điều hành bấm Áp dụng thay đổi |
| AC43 | Áp dụng thay đổi gồm Thêm, Bỏ dịch vụ chưa gửi, Bỏ dịch vụ đã xác nhận, Đổi yêu cầu dịch vụ đã xác nhận | Thêm: hạng mục Cần đặt và công việc theo mẫu. Bỏ chưa gửi: Đã hủy. Bỏ đã xác nhận: Cần hủy, email hủy soạn sẵn. Đổi yêu cầu đã xác nhận: Cần điều chỉnh, email điều chỉnh soạn sẵn. Không email nào tự gửi |
| AC44 | Gửi yêu cầu hủy cho dịch vụ Cần hủy, rồi NCC chấp nhận | Sau gửi: Đã xác nhận kèm Yêu cầu hủy đang chờ. Sau ghi kết quả: Đã hủy; phí hủy (nếu có) vào KT01.2 |
| AC45 | Kinh doanh gửi phiên bản 5 khi phiên bản 4 chưa áp dụng | Chỉ hiện phiên bản 5; phiên bản 4 Đã thay thế; so sánh bản cũ đang áp dụng (phiên bản 3) với phiên bản 5 |
| AC46 | Bấm Áp dụng hai lần hoặc hai người cùng áp dụng | Thay đổi chỉ được áp dụng một lần |
| AC47 | Hồ sơ tạo từ Inbound tiêu chuẩn v4; mẫu đã lên v5; thêm hạng mục Du thuyền ở DH08.2 | Sinh 2 việc Du thuyền theo v5, hạn theo ngày sử dụng của hạng mục mới; việc cả hồ sơ không sinh lại; các việc cũ giữ nguyên |
| AC48 | Mở công việc “Gửi Rooming list cho mọi khách sạn” | Bảng trượt ghi mẫu Inbound tiêu chuẩn v4, tự hoàn tất khi đã gửi Rooming list cho mọi khách sạn, hạn 11/11/2026 với nhãn 7 ngày trước Khởi hành, hướng dẫn chỉ đọc |
